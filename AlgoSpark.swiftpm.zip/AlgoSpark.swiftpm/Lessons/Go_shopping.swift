//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/31.
//

import SwiftUI

struct L_MAIN: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Environment(\.presentationMode) var presentationMode
    
    let onReload: () -> Void
    
    @State private var view = 1
    @State private var dismiss = false
    @State private var progress: CGFloat = 0/3
    @State private var starCount = 3
    @State private var time = 0
    @State private var timer: Timer? = nil
    @State private var showAlert = false
    
    var body: some View {
        NavigationView{
            ZStack{
                Color(.white)
                    .ignoresSafeArea()
                
                VStack{
                    HStack{
                        Button(action: {
                            Sounds.play(soundName: "btnClick")
                            showAlert = true
                            motor_return()
                        }){
                            ZStack{
                                Circle()
                                    .fill(Color(colorSet).opacity(0.1))
                                    .frame(width: 40, height: 40)
                                
                                Image("left_chev")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 18)
                                    .opacity(0.7)
                            }
                            .padding(.trailing, 8)
                        }
                        .alert(isPresented: $showAlert){
                            Alert(
                                title: Text("Exit"),
                                message: Text("Your progress might not be saved if you exit. "),
                                primaryButton: .destructive(Text("OK")) {
                                    onReload()
                                    presentationMode.wrappedValue.dismiss()
                                },
                                secondaryButton: .cancel {}
                            )
                        }
                        
                        MyProgressBar(progress: progress)
                            .padding(.trailing, 8)
                        
                        HStack{
                            Image("clock")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text(formatSecondsToMMSS(seconds: time))
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .frame(width: 60)
                                .lineLimit(1)
                                .foregroundStyle(.black)
                        }
                        
                        HStack{
                            Image("star")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text("\(starCount)")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .foregroundStyle(.black)
                        }
                    }
                    .padding()
                    
                    MyDivider()
                    
                    if view == 1 {
                        L1(view: $view, progress: $progress)
                    } else if view == 2 {
                        L2(view: $view, progress: $progress)
                    } else if view == 3 {
                        L3(view: $view, progress: $progress)
                    } else if view == 4 {
                        L4(view: $view, progress: $progress)
                    } else if view == 5 {
                        L5(view: $view, progress: $progress)
                    } else if view == 6 {
                        L6(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 7 {
                        L7(view: $view, progress: $progress)
                    } else if view == 8 {
                        L8(view: $view, progress: $progress, starCount: $starCount, time: $time)
                    } else if view == 9 {
                        L9(view: $view)
                    } else if view == 10 {
                        LessonResultView(dismiss: $dismiss, starCount: $starCount, time: $time, timer: $timer, onReload: onReload)
                    }
                }
            }
        }
        .onAppear{
            Sounds.play(soundName: "courseClick")
            motor_optionSelect()
            timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                DispatchQueue.main.async {
                    time += 1
                }
            }
        }
        .onChange(of: dismiss) { newValue in
            if newValue {
                presentationMode.wrappedValue.dismiss()
            }
        }
        .onChange(of: starCount) { newValue in
            if newValue < 1 {
                starCount = 1
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct L1: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "The purpose of algorithms is to help people solve problems. Starting from this lesson, we will explore how algorithms can solve problems through fun mini-games and discover even more exciting new algorithms!")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 2
                    progress = 1/8
                    updateLessonProgress(lessonName: "go_shopping", progress: 1/8)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct L2: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Imagine this scenario: We go shopping at the supermarket, but we only have a shopping bag that can hold up to 15 kilograms. Clearly, this bag might not be enough to carry everything we want to buy.")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 3
                    progress = 2/8
                    updateLessonProgress(lessonName: "go_shopping", progress: 2/8)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct L3: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "But we can come up with a solution: we should try to pick the more expensive items, while making sure their total weight doesn’t exceed the bag’s limit of 15 kilograms. ")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 4
                    progress = 3/8
                    updateLessonProgress(lessonName: "go_shopping", progress: 3/8)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct L4: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Here are the items in the supermarket, with their weights and prices clearly labeled. Let’s think about how we can choose the best combination of items! ")
                Spacer()
            }
            
            Spacer()
            
            HStack{
                Text("Here're the items:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.bottom)
            
            ScrollView(.horizontal) {
                HStack(spacing: 15) {
                    VStack{
                        Image("bread")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Bread")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$5·2kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                    
                    VStack{
                        Image("cake")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Cake")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$8·1kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                    
                    VStack{
                        Image("fruit")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Fruit")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$3·5kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                    
                    VStack{
                        Image("juice")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Juice")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$5·5kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                    
                    VStack{
                        Image("chip")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Chip")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$2·1kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                    
                    VStack{
                        Image("milk")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Milk")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$4·10kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                    
                    VStack{
                        Image("candy")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Candy")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$3·6kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                }
                .padding(.bottom)
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 5
                    progress = 4/8
                    updateLessonProgress(lessonName: "go_shopping", progress: 4/8)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct L5: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "To make sure the items in the shopping bag have the highest value, we need to do some calculations first: we should figure out how much each kilogram of an item costs. ")
                Spacer()
            }
            
            Spacer()
            
            HStack{
                Text("Here're the items:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.bottom)
            
            ScrollView(.horizontal) {
                HStack(spacing: 15) {
                    VStack{
                        Image("bread")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Bread")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$2.5/kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                    
                    VStack{
                        Image("cake")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Cake")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$8/kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                    
                    VStack{
                        Image("fruit")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Fruit")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$0.6/kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                    
                    VStack{
                        Image("juice")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Juice")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$1/kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                    
                    VStack{
                        Image("chip")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Chip")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$2/kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                    
                    VStack{
                        Image("milk")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Milk")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$0.4/kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                    
                    VStack{
                        Image("candy")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                        Text("Candy")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .foregroundStyle(Color(colorSet))
                        Text("$0.5/kg")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(.gray))
                    }
                    .frame(width: 80)
                }
                .padding(.bottom)
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 6
                    progress = 5/8
                    updateLessonProgress(lessonName: "go_shopping", progress: 5/8)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct L6: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var isTap = false
    @State private var selectedItems: [String] = []
    @State private var selectedItemWeights: [Int] = []
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Now that we know the price per kilogram of each item, to get the highest value in our shopping bag, we need to choose the items with the highest price per kilogram.")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Click the items to add them to the bag (Remaining bag capacity: \(cacuRemainingCapacity())kg) :")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            
            ScrollView(.horizontal) {
                HStack(spacing: 15) {
                    ZStack {
                        VStack{
                            Image("bread")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80)
                            Text("Bread")
                                .font(.system(size: 22, weight: .black, design: .rounded))
                                .foregroundStyle(Color(colorSet))
                            Text("$2.5/kg")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundStyle(Color(.gray))
                        }
                        .frame(width: 80)
                    }
                    .padding()
                    .onTapGesture {
                        Sounds.play(soundName: "optionSelect")
                        motor_optionSelect()
                        if !selectedItems.contains("bread") {
                            selectedItems.append("bread")
                            selectedItemWeights.append(2)
                        } else {
                            selectedItems.removeAll { $0 == "bread" }
                            selectedItemWeights.removeAll { $0 == 2 }
                        }
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(selectedItems.contains("bread") ? Color(colorSet) : Color.clear, lineWidth: 5)
                    )
                    
                    ZStack {
                        VStack{
                            Image("cake")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80)
                            Text("Cake")
                                .font(.system(size: 22, weight: .black, design: .rounded))
                                .foregroundStyle(Color(colorSet))
                            Text("$8/kg")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundStyle(Color(.gray))
                        }
                        .frame(width: 80)
                    }
                    .padding()
                    .onTapGesture {
                        Sounds.play(soundName: "optionSelect")
                        motor_optionSelect()
                        if !selectedItems.contains("cake") {
                            selectedItems.append("cake")
                            selectedItemWeights.append(1)
                        } else {
                            selectedItems.removeAll { $0 == "cake" }
                            selectedItemWeights.removeAll { $0 == 1 }
                        }
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(selectedItems.contains("cake") ? Color(colorSet) : Color.clear, lineWidth: 5)
                    )
                    
                    ZStack {
                        VStack{
                            Image("fruit")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80)
                            Text("Fruit")
                                .font(.system(size: 22, weight: .black, design: .rounded))
                                .foregroundStyle(Color(colorSet))
                            Text("$0.6/kg")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundStyle(Color(.gray))
                        }
                        .frame(width: 80)
                    }
                    .padding()
                    .onTapGesture {
                        Sounds.play(soundName: "optionSelect")
                        motor_optionSelect()
                        if !selectedItems.contains("fruit") {
                            selectedItems.append("fruit")
                            selectedItemWeights.append(5)
                        } else {
                            selectedItems.removeAll { $0 == "fruit" }
                            selectedItemWeights.removeAll { $0 == 5 }
                        }
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(selectedItems.contains("fruit") ? Color(colorSet) : Color.clear, lineWidth: 5)
                    )
                    
                    ZStack {
                        VStack{
                            Image("juice")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80)
                            Text("Juice")
                                .font(.system(size: 22, weight: .black, design: .rounded))
                                .foregroundStyle(Color(colorSet))
                            Text("$1/kg")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundStyle(Color(.gray))
                        }
                        .frame(width: 80)
                    }
                    .padding()
                    .onTapGesture {
                        Sounds.play(soundName: "optionSelect")
                        motor_optionSelect()
                        if !selectedItems.contains("juice") {
                            selectedItems.append("juice")
                            selectedItemWeights.append(5)
                        } else {
                            selectedItems.removeAll { $0 == "juice" }
                            selectedItemWeights.removeAll { $0 == 5 }
                        }
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(selectedItems.contains("juice") ? Color(colorSet) : Color.clear, lineWidth: 5)
                    )
                    
                    ZStack {
                        VStack{
                            Image("chip")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80)
                            Text("Chip")
                                .font(.system(size: 22, weight: .black, design: .rounded))
                                .foregroundStyle(Color(colorSet))
                            Text("$2/kg")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundStyle(Color(.gray))
                        }
                        .frame(width: 80)
                    }
                    .padding()
                    .onTapGesture {
                        Sounds.play(soundName: "optionSelect")
                        motor_optionSelect()
                        if !selectedItems.contains("chip") {
                            selectedItems.append("chip")
                            selectedItemWeights.append(1)
                        } else {
                            selectedItems.removeAll { $0 == "chip" }
                            selectedItemWeights.removeAll { $0 == 1 }
                        }
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(selectedItems.contains("chip") ? Color(colorSet) : Color.clear, lineWidth: 5)
                    )
                    
                    ZStack {
                        VStack{
                            Image("milk")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80)
                            Text("Milk")
                                .font(.system(size: 22, weight: .black, design: .rounded))
                                .foregroundStyle(Color(colorSet))
                            Text("$0.4/kg")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundStyle(Color(.gray))
                        }
                        .frame(width: 80)
                    }
                    .padding()
                    .onTapGesture {
                        Sounds.play(soundName: "optionSelect")
                        motor_optionSelect()
                        if !selectedItems.contains("milk") {
                            selectedItems.append("milk")
                            selectedItemWeights.append(10)
                        } else {
                            selectedItems.removeAll { $0 == "milk" }
                            selectedItemWeights.removeAll { $0 == 10 }
                        }
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(selectedItems.contains("milk") ? Color(colorSet) : Color.clear, lineWidth: 5)
                    )
                    
                    ZStack {
                        VStack{
                            Image("candy")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 80)
                            Text("Candy")
                                .font(.system(size: 22, weight: .black, design: .rounded))
                                .foregroundStyle(Color(colorSet))
                            Text("$0.5/kg")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .foregroundStyle(Color(.gray))
                        }
                        .frame(width: 80)
                    }
                    .padding()
                    .onTapGesture {
                        Sounds.play(soundName: "optionSelect")
                        motor_optionSelect()
                        if !selectedItems.contains("candy") {
                            selectedItems.append("candy")
                            selectedItemWeights.append(6)
                        } else {
                            selectedItems.removeAll { $0 == "candy" }
                            selectedItemWeights.removeAll { $0 == 6 }
                        }
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(selectedItems.contains("candy") ? Color(colorSet) : Color.clear, lineWidth: 5)
                    )
                }
                .padding(.horizontal)
                .padding(.bottom)
                .padding(.top, 3)
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if selectedItems.count == 5 && selectedItems.contains("bread") && selectedItems.contains("cake") && selectedItems.contains("fruit") && selectedItems.contains("juice") && selectedItems.contains("chip") {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 6/8
                                view = 7
                            }
                            updateLessonProgress(lessonName: "go_shopping", progress: 6/8)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
    
    private func cacuRemainingCapacity() -> Int {
        return 15 - selectedItemWeights.reduce(0, +) >= 0 ? 15 - selectedItemWeights.reduce(0, +) : 0
    }
}

struct L7: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Congratulations on completing your shopping! In the game, we learned how to maximize the value of the items in our shopping bag without exceeding its weight limit.")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 8
                    progress = 7/8
                    updateLessonProgress(lessonName: "go_shopping", progress: 7/8)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct L8: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    @Binding var time: Int
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "This algorithm, which ensures that the total weight of the items in the bag doesn’t exceed its capacity while maximizing the total value, is called the Greedy Algorithm. It makes the best choice at each step to get the optimal solution!")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 9
                    progress = 1
                }
                
                if time > 900 {
                    starCount -= 1
                }
                
                updateLessonProgress(lessonName: "go_shopping", progress: 1)
                updateLessonStar(lessonName: "go_shopping", star: starCount)
                setLessonStats(lessonName: "go_shopping", stats: true)
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct L9: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @State private var code = """
import Foundation

func knapsackGreedy() -> [String] {
    // Define the Item struct inside the method
    struct Item {
        let name: String
        let weight: Int
        let value: Int
        
        // Calculate the value-to-weight ratio of the item
        var valuePerWeight: Double {
            return Double(value) / Double(weight)
        }
    }
    
    // Define the items inside the method
    let items = [
        Item(name: "bread", weight: 2, value: 5),
        Item(name: "cake", weight: 1, value: 8),
        Item(name: "fruit", weight: 5, value: 3),
        Item(name: "juice", weight: 5, value: 5),
        Item(name: "chip", weight: 1, value: 2),
        Item(name: "milk", weight: 10, value: 4),
        Item(name: "candy", weight: 6, value: 3)
    ]
    
    // Sort the items based on their value-to-weight ratio in descending order
    let sortedItems = items.sorted { $0.valuePerWeight > $1.valuePerWeight }
    
    var totalWeight = 0
    var totalValue = 0
    var selectedItems: [String] = []
    
    // Select items in order of the sorted list, until the backpack reaches its max capacity
    for item in sortedItems {
        if totalWeight + item.weight <= 15 {
            totalWeight += item.weight
            totalValue += item.value
            selectedItems.append(item.name)
        }
    }
    
    // Print the total value and weight of selected items
    print("Total Value: \\(totalValue), Total Weight: \\(totalWeight)")
    print(selectedItems)
    return selectedItems
}
"""
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Here’s an example of greedy algorithm in Swift, copy the code into Swift Playgrounds and give it a try!")
                Spacer()
            }
            
            SwiftCodeView(code: code)
            
            Spacer()
            
            Button(action: {
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 10
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

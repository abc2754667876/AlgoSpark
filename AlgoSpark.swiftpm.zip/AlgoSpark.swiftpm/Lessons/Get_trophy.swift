//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/2/8.
//

import SwiftUI
import UniformTypeIdentifiers
import SceneKit

struct N_MAIN: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Environment(\.presentationMode) var presentationMode
    
    let onReload: () -> Void
    
    @State private var view = 0
    @State private var dismiss = false
    @State private var progress: CGFloat = 0/3
    @State private var starCount = 3
    @State private var time = 0
    @State private var timer: Timer? = nil
    @State private var showAlert = false
    
    var body: some View {
        NavigationView{
            ZStack{
                Color(.white)
                    .ignoresSafeArea()
                
                VStack{
                    HStack{
                        Button(action: {
                            Sounds.play(soundName: "btnClick")
                            showAlert = true
                            motor_return()
                        }){
                            ZStack{
                                Circle()
                                    .fill(Color(colorSet).opacity(0.1))
                                    .frame(width: 40, height: 40)
                                
                                Image("left_chev")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 18)
                                    .opacity(0.7)
                            }
                            .padding(.trailing, 8)
                        }
                        .alert(isPresented: $showAlert){
                            Alert(
                                title: Text("Exit"),
                                message: Text("Your progress might not be saved if you exit. "),
                                primaryButton: .destructive(Text("OK")) {
                                    onReload()
                                    presentationMode.wrappedValue.dismiss()
                                },
                                secondaryButton: .cancel {}
                            )
                        }
                        
                        MyProgressBar(progress: progress)
                            .padding(.trailing, 8)
                        
                        HStack{
                            Image("clock")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text(formatSecondsToMMSS(seconds: time))
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .frame(width: 60)
                                .lineLimit(1)
                                .foregroundStyle(.black)
                        }
                        
                        HStack{
                            Image("star")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text("\(starCount)")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .foregroundStyle(.black)
                        }
                    }
                    .padding()
                    
                    MyDivider()
                    
                    if view == 0 {
                        N0(view: $view, progress: $progress)
                    } else if view == 3 {
                        N3(view: $view, progress: $progress, starCount: $starCount, time: $time)
                    } else if view == 2 {
                        N2(view: $view, progress: $progress, starCount: $starCount, time: $time)
                    } else if view == 1 {
                        N1(view: $view, progress: $progress, starCount: $starCount, time: $time)
                    } else if view == 4 {
                        N4(dismiss: $dismiss, starCount: $starCount, time: $time, timer: $timer, onReload: onReload)
                    }
                }
            }
        }
        .onAppear{
            Sounds.play(soundName: "courseClick")
            motor_optionSelect()
            timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                DispatchQueue.main.async {
                    time += 1
                }
            }
        }
        .onChange(of: dismiss) { newValue in
            if newValue {
                presentationMode.wrappedValue.dismiss()
            }
        }
        .onChange(of: starCount) { newValue in
            if newValue < 1 {
                starCount = 1
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct N0: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    @State private var isRotated = false
    @State private var rotationAngle: Double = 0
    @State private var randomAngle: Int = 0
    @State private var gameType = 0
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Congratulations on completing all the algorithm courses! Now, complete the final mini-game to earn your trophy! Spin the wheel and pick your game. ")
                Spacer()
            }
            
            Spacer()
            
            ZStack {
                Image("prize")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300)
                    .rotationEffect(.degrees(rotationAngle))
                    .animation(.easeInOut(duration: 8), value: rotationAngle)
                Image("pointer")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
            }
            
            Spacer()
            
            if isRotated {
                Button(action: {
                    Sounds.play(soundName: "btnClick")
                    motor_buttonClick()
                    if gameType == 3 {
                        withAnimation(.easeInOut(duration: 0.5)){
                            progress = 1/2
                            view = 3
                        }
                    } else if gameType == 2 {
                        withAnimation(.easeInOut(duration: 0.5)){
                            progress = 1/2
                            view = 2
                        }
                    } else if gameType == 1 {
                        withAnimation(.easeInOut(duration: 0.5)){
                            progress = 1/20
                            view = 1
                        }
                    }
                    updateLessonProgress(lessonName: "get_trophy", progress: 1/2)
                }){
                    NextButton()
                }
            } else {
                Button(action: {
                    Sounds.play(soundName: "rotate")
                    rotationAngle = 0
                    randomAngle = generateRandomAngle()
                    gameType = getGameType(angle: randomAngle % 360)
                    withAnimation(.easeInOut(duration: 8)) {
                        rotationAngle = Double(randomAngle)
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
                        isRotated = true
                    }
                }){
                    ZStack{
                        Text("GO")
                            .font(.system(size: 30, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                    }
                    .frame(width: 80, height: 80)
                    .background(
                        ZStack {
                            LinearGradient(
                                gradient: Gradient(colors: [Color(colorSet).opacity(0.9), Color(colorSet)]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                            .clipShape(Capsule())
                            
                            Capsule()
                                .stroke(Color.black.opacity(0.3), lineWidth: 2)
                                .blur(radius: 2)
                                .offset(x: -2, y: -2)
                        }
                    )
                    .clipShape(Capsule())
                }
            }

        }
        .padding()
    }
    
    func generateRandomAngle() -> Int {
        var angle: Int
        repeat {
            angle = Int.random(in: 5400...9000)
        } while angle % 30 == 0
        return angle
    }
    
    func getGameType(angle: Int) -> Int {
        var type = 0
        
        if angle > 0 && angle < 30 {
            type = 1
        } else if angle > 30 && angle < 90 {
            type = 2
        } else if angle > 90 && angle < 150 {
            type = 3 
        } else if angle > 150 && angle < 210 {
            type = 1
        } else if angle > 210 && angle < 270 {
            type = 2
        } else if angle > 270 && angle < 330 {
            type = 3
        } else if angle > 330 && angle < 360 {
            type = 1
        }
        
        return type
    }
}

struct N3: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    @Binding var time: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var isTap = false
    @State private var selectedCells: [(Int, Int)] = []
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "You landed on the “Queen Problem”! Now, let’s complete this “Five Queens” challenge!")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Click on the grid to place the “queen”:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            
            EightQueensGrid_Five(selectedCells: $selectedCells)
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if checkCorrect(selectedCells) {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 1
                                view = 4
                            }
                            
                            if time > 900 {
                                starCount -= 1
                            }
                            
                            updateLessonProgress(lessonName: "get_trophy", progress: 1)
                            updateLessonStar(lessonName: "get_trophy", star: starCount)
                            setLessonStats(lessonName: "get_trophy", stats: true)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
    
    private func checkCorrect(_ selectedCells: [(Int, Int)]) -> Bool {
        guard selectedCells.count == 5 else { return false }
        
        var rowSet = Set<Int>()
        var colSet = Set<Int>()
        var diag1Set = Set<Int>()
        var diag2Set = Set<Int>()

        for (row, col) in selectedCells {
            if rowSet.contains(row) || colSet.contains(col) || diag1Set.contains(row - col) || diag2Set.contains(row + col) {
                return false
            }
            rowSet.insert(row)
            colSet.insert(col)
            diag1Set.insert(row - col)
            diag2Set.insert(row + col)
        }
        
        return true
    }
}

struct N2: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    @Binding var time: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var isTap = false
    @State private var imageOrder = [3, 7, 4, 10, 11, 6, 8, 9, 5]
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "You landed on the sorting problem! Now, let’s arrange the playing cards below in ascending order! (You can only swap adjacent cards.)")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Drag the books into the ascending order:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            
            ScrollView(.horizontal) {
                HStack(spacing: 10) {
                    ForEach(0..<imageOrder.count, id: \.self) { index in
                        let imageId = imageOrder[index]
                        Image("poker\(imageId == 11 ? "_joker" : "\(imageId)")")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100)
                            .shadow(radius: 2)
                            .onDrag {
                                motor_return()
                                return NSItemProvider(object: String(index) as NSString)
                            }
                            .onDrop(of: [UTType.text], delegate: TrophyDropDelegate(index: index, imageOrder: $imageOrder))
                    }
                }
                .padding(.bottom)
            }
            .padding(.horizontal)
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if imageOrder == [3, 4, 5, 6, 7, 8, 9, 10, 11] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 1
                                view = 4
                            }
                            
                            if time > 900 {
                                starCount -= 1
                            }
                            
                            updateLessonProgress(lessonName: "get_trophy", progress: 1)
                            updateLessonStar(lessonName: "get_trophy", star: starCount)
                            setLessonStats(lessonName: "get_trophy", stats: true)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

private struct TrophyDropDelegate: DropDelegate {
    let index: Int
    @Binding var imageOrder: [Int]
    
    func performDrop(info: DropInfo) -> Bool {
        guard let item = info.itemProviders(for: [UTType.text]).first else { return false }
        
        item.loadItem(forTypeIdentifier: UTType.text.identifier) { (data, error) in
            if let data = data as? Data, let sourceIndex = String(data: data, encoding: .utf8).flatMap({ Int($0) }) {
                if abs(sourceIndex - index) == 1 {
                    Task { @MainActor in
                        motor_success()
                    }
                    Sounds.play(soundName: "drag")
                    DispatchQueue.main.async {
                        imageOrder.swapAt(sourceIndex, index)
                    }
                } else {
                    Task { @MainActor in
                        motor_fail()
                    }
                    Sounds.play(soundName: "answerWrong")
                }
            }
        }
        return true
    }
}

struct N1: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    @Binding var time: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var activeLetters: [String] = []
    
    let letterNumbers: [String: Int] = [
        "1": 4, "2": 9, "3": 15, "4": 20, "5": 24, "6": 30, "7": 35, "8": 41, "9": 46, "10": 51,
        "11": 56, "12": 61, "13": 67, "14": 72, "15": 77, "16": 82, "17": 86, "18": 92, "19": 97, "20": 103,
        "21": 108, "22": 112, "23": 118, "24": 122, "25": 128, "26": 133, "27": 137, "28": 141, "29": 146, "30": 151,
        "31": 156, "32": 161, "33": 167, "34": 173, "35": 178, "36": 183, "37": 188, "38": 193, "39": 198, "40": 204,
        "41": 208, "42": 213, "43": 219, "44": 224, "45": 229, "46": 234, "47": 239, "48": 244, "49": 249, "50": 254,
        "51": 259, "52": 264, "53": 270, "54": 274, "55": 279, "56": 283, "57": 288, "58": 293, "59": 298, "60": 304,
        "61": 309, "62": 314, "63": 319, "64": 323, "65": 328, "66": 334, "67": 339, "68": 344, "69": 349, "70": 354,
        "71": 359, "72": 365, "73": 370, "74": 374, "75": 379, "76": 384, "77": 389, "78": 393, "79": 398, "80": 403,
        "81": 408, "82": 413, "83": 418, "84": 423, "85": 428, "86": 432, "87": 438, "88": 443, "89": 448, "90": 453,
        "91": 457, "92": 463, "93": 468, "94": 472, "95": 477, "96": 482, "97": 487, "98": 492, "99": 497, "100": 502
    ]
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "You landed on the searching problem! There are 100 boxes, each containing apples of different sizes (the apples are sorted from smallest to largest). Use your method to find the apple with size 334.")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Click on the box to find the apple:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            ScrollView(.horizontal) {
                HStack(spacing: 15) {
                    ForEach([
                        "1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
                        "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
                        "21", "22", "23", "24", "25", "26", "27", "28", "29", "30",
                        "31", "32", "33", "34", "35", "36", "37", "38", "39", "40",
                        "41", "42", "43", "44", "45", "46", "47", "48", "49", "50",
                        "51", "52", "53", "54", "55", "56", "57", "58", "59", "60",
                        "61", "62", "63", "64", "65", "66", "67", "68", "69", "70",
                        "71", "72", "73", "74", "75", "76", "77", "78", "79", "80",
                        "81", "82", "83", "84", "85", "86", "87", "88", "89", "90",
                        "91", "92", "93", "94", "95", "96", "97", "98", "99", "100"
                    ], id: \.self) { letter in
                        Group {
                            if activeLetters.contains(letter) {
                                NumberApple(number: letterNumbers[letter]!)
                                    .onTapGesture {
                                        Sounds.play(soundName: "btnClick")
                                        motor_optionSelect()
                                        withAnimation(.easeInOut){
                                            if let index = activeLetters.firstIndex(of: letter) {
                                                activeLetters.remove(at: index)
                                            }
                                        }
                                    }
                            } else {
                                LetterBox(letter: letter)
                                    .onTapGesture {
                                        Sounds.play(soundName: "btnClick")
                                        motor_optionSelect()
                                        withAnimation(.easeInOut){
                                            if !activeLetters.contains(letter) {
                                                activeLetters.append(letter)
                                            }
                                        }
                                    }
                            }
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if activeLetters.contains("66") {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 1
                                view = 4
                            }
                            
                            if time > 900 {
                                starCount -= 1
                            }
                            
                            updateLessonProgress(lessonName: "get_trophy", progress: 1)
                            updateLessonStar(lessonName: "get_trophy", star: starCount)
                            setLessonStats(lessonName: "get_trophy", stats: true)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct N4: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    
    @Binding var dismiss: Bool
    @Binding var starCount: Int
    @Binding var time: Int
    @Binding var timer: Timer?
    let onReload: () -> Void
    
    @State private var isShow = true
    
    var body: some View {
        VStack{
            Spacer()
            
            TrophyModelViewer()
            
            Text("YOU GOT THE TROPHY!")
                .font(.system(size: 30, weight: .black, design: .rounded))
                .foregroundStyle(Color(colorSet))
                .padding(.bottom, 30)
                .padding(.top)
            
            Spacer()
            
            Text("You can admire it later using AR.")
                .font(.system(size: 16, weight: .medium, design: .rounded))
                .foregroundStyle(.gray)
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                onReload()
                dismiss = true
            }){
                MyButton(title: "DONE", fontSize: 20, isBold: true)
            }
        }
        .onAppear{
            timer?.invalidate()
            timer = nil
            Sounds.play(soundName: "answerComplete")
        }
        .padding(.horizontal)
    }
}

struct TrophyModelViewer: View {
    @State private var scene: SCNScene?
    
    var body: some View {
        ZStack{
            SceneView(
                scene: scene,
                options: [.allowsCameraControl, .autoenablesDefaultLighting]
            )
            .onAppear {
                if let modelURL = Bundle.main.url(forResource: "trophy", withExtension: "usdz") {
                    do {
                        scene = try SCNScene(url: modelURL, options: nil)
                        
                        let cameraNode = SCNNode()
                        cameraNode.camera = SCNCamera()
                        cameraNode.position = SCNVector3(x: 0, y: 0, z: 5)
                        scene?.rootNode.addChildNode(cameraNode)
                        
                        if let modelNode = scene?.rootNode.childNodes.first {
                            modelNode.position = SCNVector3(0, 0, 0)
                            modelNode.scale = SCNVector3(0.9, 0.9, 0.9)
                        }
                    } catch {
                        print("加载模型失败: \(error)")
                    }
                }
            }
        }
        .frame(height: 300)
    }
}

//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/13.
//

import SwiftUI

struct G_MAIN: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Environment(\.presentationMode) var presentationMode
    
    let onReload: () -> Void
    
    @State private var view = 1
    @State private var dismiss = false
    @State private var progress: CGFloat = 0/3
    @State private var starCount = 3
    @State private var time = 0
    @State private var timer: Timer? = nil
    @State private var showAlert = false
    
    var body: some View {
        NavigationView{
            ZStack{
                Color(.white)
                    .ignoresSafeArea()
                
                VStack{
                    HStack{
                        Button(action: {
                            Sounds.play(soundName: "btnClick")
                            showAlert = true
                            motor_return()
                        }){
                            ZStack{
                                Circle()
                                    .fill(Color(colorSet).opacity(0.1))
                                    .frame(width: 40, height: 40)
                                
                                Image("left_chev")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 18)
                                    .opacity(0.7)
                            }
                            .padding(.trailing, 8)
                        }
                        .alert(isPresented: $showAlert){
                            Alert(
                                title: Text("Exit"),
                                message: Text("Your progress might not be saved if you exit. "),
                                primaryButton: .destructive(Text("OK")) {
                                    onReload()
                                    presentationMode.wrappedValue.dismiss()
                                },
                                secondaryButton: .cancel {}
                            )
                        }
                        
                        MyProgressBar(progress: progress)
                            .padding(.trailing, 8)
                        
                        HStack{
                            Image("clock")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text(formatSecondsToMMSS(seconds: time))
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .frame(width: 60)
                                .lineLimit(1)
                                .foregroundStyle(.black)
                        }
                        
                        HStack{
                            Image("star")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text("\(starCount)")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .foregroundStyle(.black)
                        }
                    }
                    .padding()
                    
                    MyDivider()
                    
                    if view == 1 {
                        G1(view: $view, progress: $progress)
                    } else if view == 2 {
                        G2(view: $view, progress: $progress)
                    } else if view == 3 {
                        G3(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 4 {
                        G4(view: $view, progress: $progress, starCount: $starCount, time: $time)
                    } else if view == 5 {
                        G5(view: $view)
                    } else if view == 6 {
                        LessonResultView(dismiss: $dismiss, starCount: $starCount, time: $time, timer: $timer, onReload: onReload)
                    }
                }
            }
        }
        .onAppear{
            Sounds.play(soundName: "courseClick")
            motor_optionSelect()
            timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                DispatchQueue.main.async {
                    time += 1
                }
            }
        }
        .onChange(of: dismiss) { newValue in
            if newValue {
                presentationMode.wrappedValue.dismiss()
            }
        }
        .onChange(of: starCount) { newValue in
            if newValue < 1 {
                starCount = 1
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct G1: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "If you lose your pen, you might first search on your desk, then under your bed, or somewhere else. This process of looking for something is called “searching.”")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 2
                    progress = 1/4
                    updateLessonProgress(lessonName: "meet_search", progress: 1/4)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct G2: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Searching means finding a “target” in the middle of a mess. It could be checking everything one by one or starting with the most likely places. Let’s play a game to learn more about searching!")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 3
                    progress = 2/4
                    updateLessonProgress(lessonName: "meet_search", progress: 2/4)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct G3: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    
    @State private var imageNames = Array(repeating: "box", count: 10)
    @State private var opacities = Array(repeating: 1.0, count: 10)
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Here’s a row of boxes, and one of them has an apple inside. Start clicking on the boxes one by one from the first until you find the apple! ")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Click the boxes until you find the apple:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            ScrollView(.horizontal) {
                HStack(spacing: 15) {
                    ForEach(0..<10, id: \.self) { index in
                        Image(imageNames[index])
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                            .opacity(opacities[index])
                            .animation(.easeInOut, value: opacities[index])
                            .onTapGesture {
                                withAnimation(.easeInOut) { 
                                    handleTap(on: index)
                                }
                            }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if isSpecificStateSatisfied(imageNames: imageNames, opacities: opacities) {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 3/4
                                view = 4
                            }
                            updateLessonProgress(lessonName: "meet_search", progress: 3/4)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
    
    private func handleTap(on index: Int) {
        motor_optionSelect()
        
        if index == 6 {
            if imageNames[index] == "apple" {
                Sounds.play(soundName: "btnClick")
                imageNames[index] = "box"
            } else {
                Sounds.play(soundName: "answerBingo")
                imageNames[index] = "apple"
            }
        } else {
            Sounds.play(soundName: "btnClick")
            opacities[index] = opacities[index] == 1.0 ? 0.5 : 1.0
        }
    }
    
    private func isSpecificStateSatisfied(imageNames: [String], opacities: [Double]) -> Bool {
        let areFirstSixDimmed = opacities.prefix(6).allSatisfy { $0 == 0.5 }
        let isSeventhApple = imageNames[6] == "apple"
        let areLastThreeOriginal = zip(imageNames[7...9], opacities[7...9]).allSatisfy { name, opacity in
            name == "box" && opacity == 1.0
        }
        
        return areFirstSixDimmed && isSeventhApple && areLastThreeOriginal
    }
}

struct G4: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    @Binding var time: Int
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Congratulations, you found the apple! What we just did—clicking each box from left to right—is called “linear search”. This means checking every item one by one from start to end until we find the target or reach the end of the list.")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 5
                    progress = 1
                }
                
                if time > 900 {
                    starCount -= 1
                }
                
                updateLessonProgress(lessonName: "meet_search", progress: 1)
                updateLessonStar(lessonName: "meet_search", star: starCount)
                setLessonStats(lessonName: "meet_search", stats: true)
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct G5: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @State private var code = """
import Foundation

func linearSearch() -> Int? {
    // Sample array containing 10 numbers
    let array = [3, 5, 7, 9, 11, 13, 17, 19, 23, 29]
    let target = 17 // The target number to search for (the 7th number)
    
    for (index, element) in array.enumerated() {
        if element == target {
            return index // Target found, return its index
        }
    }
    return nil // Target not found, return nil
}
"""
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Here’s an example of linear search in Swift, copy the code into Swift Playgrounds and give it a try!")
                Spacer()
            }
            
            SwiftCodeView(code: code)
            
            Spacer()
            
            Button(action: {
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 6
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

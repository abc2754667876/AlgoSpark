//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/4.
//

import SwiftUI

struct B_MAIN: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Environment(\.presentationMode) var presentationMode
    
    let onReload: () -> Void
    
    @State private var view = 1
    @State private var dismiss = false
    @State private var progress: CGFloat = 0/3
    @State private var starCount = 3
    @State private var time = 0
    @State private var timer: Timer? = nil
    @State private var showAlert = false
    
    var body: some View {
        NavigationView{
            ZStack{
                Color(.white)
                    .ignoresSafeArea()
                
                VStack{
                    HStack{
                        Button(action: {
                            Sounds.play(soundName: "btnClick")
                            showAlert = true
                            motor_return()
                        }){
                            ZStack{
                                Circle()
                                    .fill(Color(colorSet).opacity(0.1))
                                    .frame(width: 40, height: 40)
                                
                                Image("left_chev")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 18)
                                    .opacity(0.7)
                            }
                            .padding(.trailing, 8)
                        }
                        .alert(isPresented: $showAlert){
                            Alert(
                                title: Text("Exit"),
                                message: Text("Your progress might not be saved if you exit. "),
                                primaryButton: .destructive(Text("OK")) {
                                    onReload()
                                    presentationMode.wrappedValue.dismiss()
                                },
                                secondaryButton: .cancel {}
                            )
                        }
                        
                        MyProgressBar(progress: progress)
                            .padding(.trailing, 8)
                        
                        HStack{
                            Image("clock")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text(formatSecondsToMMSS(seconds: time))
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .frame(width: 60)
                                .lineLimit(1)
                                .foregroundStyle(.black)
                        }
                        
                        HStack{
                            Image("star")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text("\(starCount)")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .foregroundStyle(.black)
                        }
                    }
                    .padding()
                    
                    MyDivider()
                    
                    if view == 1 {
                        B1(view: $view, progress: $progress)
                    } else if view == 2 {
                        B2(view: $view, progress: $progress, time: $time, starCount: $starCount)
                    } else if view == 3 {
                        B3(view: $view)
                    } else if view == 4 {
                        LessonResultView(dismiss: $dismiss, starCount: $starCount, time: $time, timer: $timer, onReload: onReload)
                    }
                }
            }
        }
        .onAppear{
            Sounds.play(soundName: "courseClick")
            motor_optionSelect()
            timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                DispatchQueue.main.async {
                    time += 1
                }
            }
        }
        .onChange(of: dismiss) { newValue in
            if newValue {
                presentationMode.wrappedValue.dismiss()
            }
        }
        .onChange(of: starCount) { newValue in
            if newValue < 1 {
                starCount = 1
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct B1: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "We’ve learned what an algorithm is, so now let’s play a little game! ")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 2
                    progress = 1/2
                    updateLessonProgress(lessonName: "brush_teeth", progress: 1/2)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct B2: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var time: Int
    @Binding var starCount: Int
    
    @State private var selectedOrder: [Int?] = [nil, nil, nil] 
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Let’s say you just woke up and need to brush your teeth. Can you put the steps in the right order? ")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Tap the steps below to put them in the right brushing order! ")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            
            HStack {
                Spacer()
                
                ForEach(0..<3, id: \.self) { index in
                    ZStack(alignment: .topLeading) {
                        Image(images[index])
                            .resizable()
                            .scaledToFit()
                            .padding()
                            .frame(width: 110)
                            .background(Color.white)
                            .cornerRadius(25)
                            .overlay(
                                RoundedRectangle(cornerRadius: 25)
                                    .stroke(
                                        selectedOrder[index] != nil ? Color(colorSet) : Color(colorSet).opacity(0.1),
                                        lineWidth: 4
                                    )
                            )
                        
                        if let order = selectedOrder[index] {
                            ZStack{
                                Circle()
                                    .frame(width: 25)
                                    .frame(height: 25)
                                    .foregroundStyle(Color(colorSet))
                                Text("\(order)")
                                    .font(.system(size: 18, weight: .black, design: .rounded))
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, 10)
                            .padding(.top, 10)
                        }
                    }
                    .onTapGesture {
                        Sounds.play(soundName: "optionSelect")
                        motor_optionSelect()
                        handleSelection(for: index)
                    }
                    
                    if index < 2 { Spacer() }
                }
                
                Spacer()
            }
            .padding(.top)
            .padding(.horizontal)
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if selectedOrder.compactMap({ $0 }).count == 3 {
                                if selectedOrder.compactMap({ $0 }) == [2, 3, 1] {
                                    answerStats = 1
                                    answerBgColor = "bingo"
                                    answerBtColor = "bingo"
                                    answerText = "BINGO!"
                                    checkButtonText = "CONTINUE"
                                    Sounds.play(soundName: "answerBingo")
                                    motor_success()
                                } else {
                                    answerStats = 2
                                    answerBgColor = "wrong"
                                    answerBtColor = "wrong"
                                    answerText = "THINK TWICE!"
                                    
                                    if starCount >= 1 {
                                        starCount -= 1
                                    }
                                    
                                    Sounds.play(soundName: "answerWrong")
                                    motor_fail()
                                }
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount >= 1 && time > 900 {
                                starCount -= 1
                            }
                            
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            updateLessonStar(lessonName: "brush_teeth", star: starCount)
                            setLessonStats(lessonName: "brush_teeth", stats: true)
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 1
                                view = 3
                            }
                            updateLessonProgress(lessonName: "brush_teeth", progress: 1)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
    
    private var images: [String] {
        ["add_toothpaste", "brush", "get_water"]
    }
    
    private func handleSelection(for index: Int) {
        if let currentOrder = selectedOrder[index] {
            selectedOrder[index] = nil
            for i in 0..<selectedOrder.count {
                if let order = selectedOrder[i], order > currentOrder {
                    selectedOrder[i]! -= 1
                }
            }
        } else {
            let newOrder = (selectedOrder.compactMap { $0 }.max() ?? 0) + 1
            selectedOrder[index] = newOrder
        }
    }
}

struct B3: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @State private var code = """
import Foundation

func BrushMyTeeth(){
    print("1. Get water 💧")
    print("2. Add toothpaste 🪥")
    print("3. Brush teeth 😁")
}
"""
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Here’s the Swift code to simulate “brushing teeth.” You can copy it into Swift Playgrounds and try it out! ")
                Spacer()
            }
            
            SwiftCodeView(code: code)
            
            Spacer()
            
            Button(action: {
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 4
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/7.
//

import SwiftUI

struct D_MAIN: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Environment(\.presentationMode) var presentationMode
    
    let onReload: () -> Void
    
    @State private var view = 1
    @State private var dismiss = false
    @State private var progress: CGFloat = 0/3
    @State private var starCount = 3
    @State private var time = 0
    @State private var timer: Timer? = nil
    @State private var showAlert = false
    
    var body: some View {
        NavigationView{
            ZStack{
                Color(.white)
                    .ignoresSafeArea()
                
                VStack{
                    HStack{
                        Button(action: {
                            Sounds.play(soundName: "btnClick")
                            showAlert = true
                            motor_return()
                        }){
                            ZStack{
                                Circle()
                                    .fill(Color(colorSet).opacity(0.1))
                                    .frame(width: 40, height: 40)
                                
                                Image("left_chev")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 18)
                                    .opacity(0.7)
                            }
                            .padding(.trailing, 8)
                        }
                        .alert(isPresented: $showAlert){
                            Alert(
                                title: Text("Exit"),
                                message: Text("Your progress might not be saved if you exit. "),
                                primaryButton: .destructive(Text("OK")) {
                                    onReload()
                                    presentationMode.wrappedValue.dismiss()
                                },
                                secondaryButton: .cancel {}
                            )
                        }
                        
                        MyProgressBar(progress: progress)
                            .padding(.trailing, 8)
                        
                        HStack{
                            Image("clock")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text(formatSecondsToMMSS(seconds: time))
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .frame(width: 60)
                                .lineLimit(1)
                                .foregroundStyle(.black)
                        }
                        
                        HStack{
                            Image("star")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text("\(starCount)")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .foregroundStyle(.black)
                        }
                    }
                    .padding()
                    
                    MyDivider()
                    
                    if view == 1 {
                        D1(view: $view, progress: $progress)
                    } else if view == 2 {
                        D2(view: $view, progress: $progress)
                    } else if view == 3 {
                        D3(view: $view, progress: $progress)
                    } else if view == 4 {
                        D4(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 5 {
                        D5(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 6 {
                        D6(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 7 {
                        D7(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 8 {
                        D8(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 9 {
                        D9(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 10 {
                        D10(view: $view, progress: $progress)
                    } else if view == 11 {
                        D11(view: $view, progress: $progress, starCount: $starCount, time: $time)
                    } else if view == 12 {
                        D12(view: $view)
                    } else if view == 13 {
                        LessonResultView(dismiss: $dismiss, starCount: $starCount, time: $time, timer: $timer, onReload: onReload)
                    }
                }
            }
        }
        .onAppear{
            Sounds.play(soundName: "courseClick")
            motor_optionSelect()
            timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                DispatchQueue.main.async {
                    time += 1
                }
            }
        }
        .onChange(of: dismiss) { newValue in
            if newValue {
                presentationMode.wrappedValue.dismiss()
            }
        }
        .onChange(of: starCount) { newValue in
            if newValue < 1 {
                starCount = 1
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct D1: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Let’s meet a new algorithm: Bubble Sort! If we have a group of numbers, how can we sort them from smallest to largest? Imagine the numbers are like bubbles—can we make the biggest bubble float to the top?")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 2
                    progress = 1/11
                    updateLessonProgress(lessonName: "bubble_sort", progress: 1/11)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct D2: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "The answer is yes! Bubble sort works by comparing two neighboring numbers. If the first one is bigger than the second, we swap them to arrange them from smallest to largest. By repeatedly comparing and swapping, we can eventually sort the entire list!")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 3
                    progress = 2/11
                    updateLessonProgress(lessonName: "bubble_sort", progress: 2/11)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct D3: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Now we have four bubbles! Let’s use bubble sort to arrange them from smallest to largest.")
                Spacer()
            }
            
            Spacer()
            
            HStack{
                Text("Here are the bubbles:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.bottom)
            
            HStack{
                Spacer()
                NumberBubble(number: 9)
                Spacer()
                NumberBubble(number: 7)
                Spacer()
                NumberBubble(number: 2)
                Spacer()
                NumberBubble(number: 6)
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 4
                    progress = 3/11
                    updateLessonProgress(lessonName: "bubble_sort", progress: 3/11)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct D4: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var numbers: [Int] = [9, 7, 2, 6]
    @State private var draggingNumber: Int? = nil
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "First, let’s compare 9 and 7. To arrange the bubbles from smallest to largest, 7 should come before 9. So, we need to swap their positions. ")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Drag 9 or 7 to swap their positions:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            HStack {
                Spacer()
                ForEach(numbers.indices, id: \.self) { index in
                    NumberBubble(number: numbers[index])
                        .onDrag {
                            motor_return()
                            draggingNumber = numbers[index]
                            return NSItemProvider(object: "\(numbers[index])" as NSString)
                        }
                        .onDrop(of: [.text], delegate: DropReceiver(
                            fromIndex: index,
                            draggingNumber: $draggingNumber,
                            numbers: $numbers
                        ))
                    Spacer()
                }
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if numbers == [7, 9, 2, 6] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 4/11
                                view = 5
                            }
                            updateLessonProgress(lessonName: "bubble_sort", progress: 4/11)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct D5: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var numbers: [Int] = [7, 9, 2, 6]
    @State private var draggingNumber: Int? = nil
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Now that we’ve compared the first and second numbers, let’s move on to the second and third: 9 and 2. Do you think 9 and 2 need to swap places?")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Drag 9 or 2 if you think they need to swap places:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            HStack {
                Spacer()
                ForEach(numbers.indices, id: \.self) { index in
                    NumberBubble(number: numbers[index])
                        .onDrag {
                            motor_return()
                            draggingNumber = numbers[index]
                            return NSItemProvider(object: "\(numbers[index])" as NSString)
                        }
                        .onDrop(of: [.text], delegate: DropReceiver(
                            fromIndex: index,
                            draggingNumber: $draggingNumber,
                            numbers: $numbers
                        ))
                    Spacer()
                }
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if numbers == [7, 2, 9, 6] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                               
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 5/11
                                view = 6
                            }
                            updateLessonProgress(lessonName: "bubble_sort", progress: 5/11)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct D6: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var numbers: [Int] = [7, 2, 9, 6]
    @State private var draggingNumber: Int? = nil
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Next, we’ll compare the last two numbers: 9 and 6.")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Drag 9 or 6 if you think they need to swap places:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            HStack {
                Spacer()
                ForEach(numbers.indices, id: \.self) { index in
                    NumberBubble(number: numbers[index])
                        .onDrag {
                            motor_return()
                            draggingNumber = numbers[index]
                            return NSItemProvider(object: "\(numbers[index])" as NSString)
                        }
                        .onDrop(of: [.text], delegate: DropReceiver(
                            fromIndex: index,
                            draggingNumber: $draggingNumber,
                            numbers: $numbers
                        ))
                    Spacer()
                }
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if numbers == [7, 2, 6, 9] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 6/11
                                view = 7
                            }
                            updateLessonProgress(lessonName: "bubble_sort", progress: 6/11)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct D7: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var numbers: [Int] = [7, 2, 6, 9]
    @State private var draggingNumber: Int? = nil
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Congratulations on completing the first round of bubble sorting! We’ve moved the largest number, 9, to its correct spot. Now, let’s continue comparing and sorting the first three numbers. Let’s start by comparing 7 and 2.")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Drag 7 or 2 if you think they need to swap places:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            HStack {
                Spacer()
                ForEach(numbers.indices, id: \.self) { index in
                    NumberBubble(number: numbers[index])
                        .onDrag {
                            motor_return()
                            draggingNumber = numbers[index]
                            return NSItemProvider(object: "\(numbers[index])" as NSString)
                        }
                        .onDrop(of: [.text], delegate: DropReceiver(
                            fromIndex: index,
                            draggingNumber: $draggingNumber,
                            numbers: $numbers
                        ))
                    Spacer()
                }
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if numbers == [2, 7, 6, 9] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 7/11
                                view = 8
                            }
                            updateLessonProgress(lessonName: "bubble_sort", progress: 7/11)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct D8: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var numbers: [Int] = [2, 7, 6, 9]
    @State private var draggingNumber: Int? = nil
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Next, let’s compare 7 and 6. Do you think they need to swap places? ")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Drag 7 or 6 if you think they need to swap places:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            HStack {
                Spacer()
                ForEach(numbers.indices, id: \.self) { index in
                    NumberBubble(number: numbers[index])
                        .onDrag {
                            motor_return()
                            draggingNumber = numbers[index]
                            return NSItemProvider(object: "\(numbers[index])" as NSString)
                        }
                        .onDrop(of: [.text], delegate: DropReceiver(
                            fromIndex: index,
                            draggingNumber: $draggingNumber,
                            numbers: $numbers
                        ))
                    Spacer()
                }
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if numbers == [2, 6, 7, 9] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 8/11
                                view = 9
                            }
                            updateLessonProgress(lessonName: "bubble_sort", progress: 8/11)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct D9: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var numbers: [Int] = [2, 6, 7, 9]
    @State private var draggingNumber: Int? = nil
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Even though it looks like everything is sorted now, we should double-check the first two numbers for accuracy. Do they need to swap places?")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Drag 2 or 6 if you think they need to swap places:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            HStack {
                Spacer()
                ForEach(numbers.indices, id: \.self) { index in
                    NumberBubble(number: numbers[index])
                        .onDrag {
                            motor_return()
                            draggingNumber = numbers[index]
                            return NSItemProvider(object: "\(numbers[index])" as NSString)
                        }
                        .onDrop(of: [.text], delegate: DropReceiver(
                            fromIndex: index,
                            draggingNumber: $draggingNumber,
                            numbers: $numbers
                        ))
                    Spacer()
                }
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if numbers == [2, 6, 7, 9] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 9/11
                                view = 10
                            }
                            updateLessonProgress(lessonName: "bubble_sort", progress: 9/11)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct D10: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Congratulations on completing the bubble sort for all the numbers! ")
                Spacer()
            }
            
            Spacer()
            
            HStack{
                Text("Here are the bubbles:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.bottom)
            
            HStack{
                Spacer()
                NumberBubble(number: 2)
                Spacer()
                NumberBubble(number: 6)
                Spacer()
                NumberBubble(number: 7)
                Spacer()
                NumberBubble(number: 9)
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 11
                    progress = 10/11
                    updateLessonProgress(lessonName: "bubble_sort", progress: 10/11)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct D11: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    @Binding var time: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var numbers: [Int] = [1, 4, 6, 8]
    @State private var draggingNumber: Int? = nil
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Now let’s strengthen what we’ve learned! Use the bubble sort method to arrange these four bubbles in descending order (from largest to smallest).")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Drag the numbers to complete the sorting! Let’s arrange them from largest to smallest:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            HStack {
                Spacer()
                ForEach(numbers.indices, id: \.self) { index in
                    NumberBubble(number: numbers[index])
                        .onDrag {
                            motor_return()
                            draggingNumber = numbers[index]
                            return NSItemProvider(object: "\(numbers[index])" as NSString)
                        }
                        .onDrop(of: [.text], delegate: DropReceiver(
                            fromIndex: index,
                            draggingNumber: $draggingNumber,
                            numbers: $numbers
                        ))
                    Spacer()
                }
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if numbers == [8, 6, 4, 1] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount >= 1 && time > 900 {
                                starCount -= 1
                            }
                            
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 1
                                view = 12
                            }
                            updateLessonStar(lessonName: "bubble_sort", star: starCount)
                            setLessonStats(lessonName: "bubble_sort", stats: true)
                            updateLessonProgress(lessonName: "bubble_sort", progress: 1)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct D12: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @State private var code = """
import Foundation

func bubbleSort() {
    // Define the array
    var arr = [2, 7, 6, 9]
    let n = arr.count
    
    // Bubble sort logic
    for i in 0..<n {
        var swapped = false // A flag for optimization
        for j in 0..<(n - i - 1) {
            if arr[j] > arr[j + 1] {
                // Swap adjacent elements
                arr.swapAt(j, j + 1)
                swapped = true
            }
        }
        // If no swaps happened in this round, exit early
        if !swapped {
            break
        }
    }
    // Print the sorted array
    print("Sorted array: \\(arr)")
}
"""
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Here’s the Swift code to perform an ascending bubble sort on the array [2, 7, 6, 9], copy the code into Swift Playgrounds and give it a try!")
                Spacer()
            }
            
            SwiftCodeView(code: code)
            
            Spacer()
            
            Button(action: {
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 13
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

private struct DropReceiver: DropDelegate {
    let fromIndex: Int
    @Binding var draggingNumber: Int?
    @Binding var numbers: [Int]

    func performDrop(info: DropInfo) -> Bool {
        Sounds.play(soundName: "drag")
        motor_success()
        guard let draggingNumber = draggingNumber,
              let fromIndex = numbers.firstIndex(of: draggingNumber) else { return false }

        numbers.swapAt(fromIndex, self.fromIndex)
        return true
    }
}

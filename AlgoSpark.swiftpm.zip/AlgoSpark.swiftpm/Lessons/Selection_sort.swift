//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/8.
//

import SwiftUI

struct E_MAIN: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Environment(\.presentationMode) var presentationMode
    
    let onReload: () -> Void
    
    @State private var view = 1
    @State private var dismiss = false
    @State private var progress: CGFloat = 0/3
    @State private var starCount = 3
    @State private var time = 0
    @State private var timer: Timer? = nil
    @State private var showAlert = false
    
    var body: some View {
        NavigationView{
            ZStack{
                Color(.white)
                    .ignoresSafeArea()
                
                VStack{
                    HStack{
                        Button(action: {
                            Sounds.play(soundName: "btnClick")
                            showAlert = true
                            motor_return()
                        }){
                            ZStack{
                                Circle()
                                    .fill(Color(colorSet).opacity(0.1))
                                    .frame(width: 40, height: 40)
                                
                                Image("left_chev")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 18)
                                    .opacity(0.7)
                            }
                            .padding(.trailing, 8)
                        }
                        .alert(isPresented: $showAlert){
                            Alert(
                                title: Text("Exit"),
                                message: Text("Your progress might not be saved if you exit. "),
                                primaryButton: .destructive(Text("OK")) {
                                    onReload()
                                    presentationMode.wrappedValue.dismiss()
                                },
                                secondaryButton: .cancel {}
                            )
                        }
                        
                        MyProgressBar(progress: progress)
                            .padding(.trailing, 8)
                        
                        HStack{
                            Image("clock")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text(formatSecondsToMMSS(seconds: time))
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .frame(width: 60)
                                .lineLimit(1)
                                .foregroundStyle(.black)
                        }
                        
                        HStack{
                            Image("star")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text("\(starCount)")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .foregroundStyle(.black)
                        }
                    }
                    .padding()
                    
                    MyDivider()
                    
                    if view == 1 {
                        E1(view: $view, progress: $progress)
                    } else if view == 3 {
                        E3(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 2 {
                        E2(view: $view, progress: $progress)
                    } else if view == 4 {
                        E4(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 5 {
                        E5(view: $view, progress: $progress, starCount: $starCount, time: $time)
                    } else if view == 6 {
                        E6(view: $view)
                    } else if view == 7 {
                        LessonResultView(dismiss: $dismiss, starCount: $starCount, time: $time, timer: $timer, onReload: onReload)
                    }
                }
            }
        }
        .onAppear{
            Sounds.play(soundName: "courseClick")
            motor_optionSelect()
            timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                DispatchQueue.main.async {
                    time += 1
                }
            }
        }
        .onChange(of: dismiss) { newValue in
            if newValue {
                presentationMode.wrappedValue.dismiss()
            }
        }
        .onChange(of: starCount) { newValue in
            if newValue < 1 {
                starCount = 1
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct E1: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "After the last two lessons, you’ve likely understood the basics of sorting algorithms. Now, let’s move on to another one: Selection Sort! ")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 2
                    progress = 1/5
                    updateLessonProgress(lessonName: "selection_sort", progress: 1/5)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct E2: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Selection sort is super simple! All we need to do is find the smallest (or largest) number in the unsorted part, place it in the correct position, and swap. That’s it!")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 3
                    progress = 2/5
                    updateLessonProgress(lessonName: "selection_sort", progress: 2/5)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct E3: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var numbers: [Int] = [5, 4, 3, 2, 1]
    @State private var draggingNumber: Int? = nil
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Now we have the numbers: 5, 4, 3, 2, 1. First, find the smallest number, which is 1, and swap it with the first number, 5. ")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Drag 1 to swap it with 5:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            ScrollView(.horizontal){
                HStack(spacing: 15) {
                    ForEach(numbers.indices, id: \.self) { index in
                        NumberCard(number: numbers[index])
                            .onDrag {
                                motor_return()
                                draggingNumber = numbers[index]
                                return NSItemProvider(object: "\(numbers[index])" as NSString)
                            }
                            .onDrop(of: [.text], delegate: SelectionDropReceiver(
                                fromIndex: index,
                                draggingNumber: $draggingNumber,
                                numbers: $numbers
                            ))
                    }
                }
                .padding(.bottom)
            }
            .padding(.horizontal)
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if numbers == [1, 4, 3, 2, 5] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 3/5
                                view = 4
                            }
                            updateLessonProgress(lessonName: "selection_sort", progress: 3/5)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct E4: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var numbers: [Int] = [1, 4, 3, 2, 5]
    @State private var draggingNumber: Int? = nil
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Next, find the smallest number in the unsorted part. It’s 2. Swap it with the second number, 4. ")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Drag 2 to swap it with 4:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            ScrollView(.horizontal){
                HStack(spacing: 15) {
                    ForEach(numbers.indices, id: \.self) { index in
                        NumberCard(number: numbers[index])
                            .onDrag {
                                motor_return()
                                draggingNumber = numbers[index]
                                return NSItemProvider(object: "\(numbers[index])" as NSString)
                            }
                            .onDrop(of: [.text], delegate: SelectionDropReceiver(
                                fromIndex: index,
                                draggingNumber: $draggingNumber,
                                numbers: $numbers
                            ))
                    }
                }
                .padding(.bottom)
            }
            .padding(.horizontal)
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if numbers == [1, 2, 3, 4, 5] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 4/5
                                view = 5
                            }
                            updateLessonProgress(lessonName: "selection_sort", progress: 4/5)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct E5: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    @Binding var time: Int
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Great job! Now all the numbers are sorted. Let’s recap: Selection sort works by finding the smallest (or largest) number in the unsorted part, placing it in the correct position, and swapping until the entire list is sorted.")
                Spacer()
            }
            
            Spacer()
            
            HStack{
                Text("Here are the sorted numbers:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.bottom)
            
            ScrollView(.horizontal){
                HStack(spacing: 15) {
                    NumberCard(number: 1)
                    NumberCard(number: 2)
                    NumberCard(number: 3)
                    NumberCard(number: 4)
                    NumberCard(number: 5)
                }
                .padding(.bottom)
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                
                if time > 900 {
                    starCount -= 1
                }
                
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 6
                    progress = 1
                }
                updateLessonProgress(lessonName: "selection_sort", progress: 1)
                updateLessonStar(lessonName: "selection_sort", star: starCount)
                setLessonStats(lessonName: "selection_sort", stats: true)
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct E6: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @State private var code = """
import Foundation

func selectionSortAndPrint() {
    var numbers = [5, 4, 3, 2, 1] // Define the array to be sorted
    let count = numbers.count
    
    print("Initial array: \\(numbers)")
    
    for i in 0..<count - 1 {
        var minIndex = i
        // Find the index of the smallest value in the unsorted part
        for j in i + 1..<count {
            if numbers[j] < numbers[minIndex] {
                minIndex = j
            }
        }
        // Swap the current element with the smallest value
        if i != minIndex {
            numbers.swapAt(i, minIndex)
        }
        // Print the result of each step
        print("Step \\(i + 1): \\(numbers)")
    }
    
    print("Final sorted array: \\(numbers)")
}
"""
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Here’s the Swift code for Selection Sort, copy the code into Swift Playgrounds and give it a try!")
                Spacer()
            }
            
            SwiftCodeView(code: code)
            
            Spacer()
            
            Button(action: {
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 7
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

private struct SelectionDropReceiver: DropDelegate {
    let fromIndex: Int
    @Binding var draggingNumber: Int?
    @Binding var numbers: [Int]

    func performDrop(info: DropInfo) -> Bool {
        Sounds.play(soundName: "drag")
        motor_success()
        guard let draggingNumber = draggingNumber,
              let fromIndex = numbers.firstIndex(of: draggingNumber) else { return false }

        numbers.swapAt(fromIndex, self.fromIndex)
        return true
    }
}

//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/26.
//

import SwiftUI

struct K_MAIN: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Environment(\.presentationMode) var presentationMode
    
    let onReload: () -> Void
    
    @State private var view = 1
    @State private var dismiss = false
    @State private var progress: CGFloat = 0/3
    @State private var starCount = 3
    @State private var time = 0
    @State private var timer: Timer? = nil
    @State private var showAlert = false
    
    var body: some View {
        NavigationView{
            ZStack{
                Color(.white)
                    .ignoresSafeArea()
                
                VStack{
                    HStack{
                        Button(action: {
                            Sounds.play(soundName: "btnClick")
                            showAlert = true
                            motor_return()
                        }){
                            ZStack{
                                Circle()
                                    .fill(Color(colorSet).opacity(0.1))
                                    .frame(width: 40, height: 40)
                                
                                Image("left_chev")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 18)
                                    .opacity(0.7)
                            }
                            .padding(.trailing, 8)
                        }
                        .alert(isPresented: $showAlert){
                            Alert(
                                title: Text("Exit"),
                                message: Text("Your progress might not be saved if you exit. "),
                                primaryButton: .destructive(Text("OK")) {
                                    onReload()
                                    presentationMode.wrappedValue.dismiss()
                                },
                                secondaryButton: .cancel {}
                            )
                        }
                        
                        MyProgressBar(progress: progress)
                            .padding(.trailing, 8)
                        
                        HStack{
                            Image("clock")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text(formatSecondsToMMSS(seconds: time))
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .frame(width: 60)
                                .lineLimit(1)
                                .foregroundStyle(.black)
                        }
                        
                        HStack{
                            Image("star")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text("\(starCount)")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .foregroundStyle(.black)
                        }
                    }
                    .padding()
                    
                    MyDivider()
                    
                    if view == 1 {
                        K1(view: $view, progress: $progress)
                    } else if view == 2 {
                        K2(view: $view, progress: $progress)
                    } else if view == 3 {
                        K3(view: $view, progress: $progress)
                    } else if view == 4 {
                        K4(view: $view, progress: $progress)
                    } else if view == 5 {
                        K5(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 6 {
                        K6(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 7 {
                        K7(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 8 {
                        K8(view: $view, progress: $progress, starCount: $starCount, time: $time)
                    } else if view == 9 {
                        K9(view: $view)
                    } else if view == 10 {
                        LessonResultView(dismiss: $dismiss, starCount: $starCount, time: $time, timer: $timer, onReload: onReload)
                    }
                }
            }
        }
        .onAppear{
            Sounds.play(soundName: "courseClick")
            motor_optionSelect()
            timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                DispatchQueue.main.async {
                    time += 1
                }
            }
        }
        .onChange(of: dismiss) { newValue in
            if newValue {
                presentationMode.wrappedValue.dismiss()
            }
        }
        .onChange(of: starCount) { newValue in
            if newValue < 1 {
                starCount = 1
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct K1: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "We’ve learned about linear search, where we start checking each element from the beginning (or the end) one by one until we find the target. But there’s a big problem: the more elements there are, the more times we have to check, and it takes longer!")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 2
                    progress = 1/8
                    updateLessonProgress(lessonName: "binary_search", progress: 1/8)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct K2: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Imagine this: If we already have a sorted list of numbers and want to find a target number, wouldn’t it be possible to reduce the search range using a method to make the search more efficient?")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 3
                    progress = 1/4
                    updateLessonProgress(lessonName: "binary_search", progress: 1/4)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct K3: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Binary Search is exactly this kind of algorithm. It quickly finds the target element by repeatedly halving the search range. Let’s dive into binary search and experience how it works!")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 4
                    progress = 3/8
                    updateLessonProgress(lessonName: "binary_search", progress: 3/8)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct K4: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Here’s a line of boxes numbered from A to K, each containing apples of different sizes (and the apples are sorted from smallest to largest). Our goal is to find the apple of size 40. ")
                Spacer()
            }
            
            Spacer()
            
            HStack{
                Text("Here're the boxes:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.bottom)
            
            ScrollView(.horizontal) {
                HStack(spacing: 15) {
                    LetterBox(letter: "A")
                    LetterBox(letter: "B")
                    LetterBox(letter: "C")
                    LetterBox(letter: "D")
                    LetterBox(letter: "E")
                    LetterBox(letter: "F")
                    LetterBox(letter: "G")
                    LetterBox(letter: "H")
                    LetterBox(letter: "I")
                    LetterBox(letter: "J")
                    LetterBox(letter: "K")
                }
                .padding(.bottom)
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 5
                    progress = 1/2
                    updateLessonProgress(lessonName: "binary_search", progress: 1/2)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct K5: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var activeLetters: [String] = []
    
    let letterNumbers: [String: Int] = [
        "A": 1, "B": 4, "C": 7, "D": 17, "E": 29, "F": 37,
        "G": 39, "H": 40, "I": 56, "J": 63, "K": 66
    ]
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "First, we reduce the search range by checking the middle box to see if it contains the apple we’re looking for.")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Click on the box labeled F to check the middle one:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            ScrollView(.horizontal) {
                HStack(spacing: 15) {
                    ForEach(["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"], id: \.self) { letter in
                        Group {
                            if activeLetters.contains(letter) {
                                NumberApple(number: letterNumbers[letter]!)
                                    .onTapGesture {
                                        Sounds.play(soundName: "btnClick")
                                        motor_optionSelect()
                                        withAnimation(.easeInOut){
                                            if let index = activeLetters.firstIndex(of: letter) {
                                                activeLetters.remove(at: index)
                                            }
                                        }
                                    }
                            } else {
                                LetterBox(letter: letter)
                                    .onTapGesture {
                                        Sounds.play(soundName: "btnClick")
                                        motor_optionSelect()
                                        withAnimation(.easeInOut){
                                            if !activeLetters.contains(letter) {
                                                activeLetters.append(letter)
                                            }
                                        }
                                    }
                            }
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if activeLetters == ["F"] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 5/8
                                view = 6
                            }
                            updateLessonProgress(lessonName: "binary_search", progress: 5/8)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct K6: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var activeLetters: [String] = []
    
    let letterNumbers: [String: Int] = [
        "G": 39, "H": 40, "I": 56, "J": 63, "K": 66
    ]
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "It seems that the apple in the middle box labeled F is size 37, not 40. Clearly, the apple we’re looking for is in the second half. Let’s continue searching in the second half and check the middle box again to see if it contains the apple we’re after! ")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Click on the box labeled I to check the middle one:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            ScrollView(.horizontal) {
                HStack(spacing: 15) {
                    ForEach(["G", "H", "I", "J", "K"], id: \.self) { letter in
                        Group {
                            if activeLetters.contains(letter) {
                                NumberApple(number: letterNumbers[letter]!)
                                    .onTapGesture {
                                        Sounds.play(soundName: "btnClick")
                                        motor_optionSelect()
                                        withAnimation(.easeInOut){
                                            if let index = activeLetters.firstIndex(of: letter) {
                                                activeLetters.remove(at: index)
                                            }
                                        }
                                    }
                            } else {
                                LetterBox(letter: letter)
                                    .onTapGesture {
                                        Sounds.play(soundName: "btnClick")
                                        motor_optionSelect()
                                        withAnimation(.easeInOut){
                                            if !activeLetters.contains(letter) {
                                                activeLetters.append(letter)
                                            }
                                        }
                                    }
                            }
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if activeLetters == ["I"] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 6/8
                                view = 7
                            }
                            updateLessonProgress(lessonName: "binary_search", progress: 6/8)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct K7: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    @State private var activeLetters: [String] = []
    
    let letterNumbers: [String: Int] = [
        "G": 39, "H": 40
    ]
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "The middle box labeled I contains an apple of size 56, not 40. Now, we know that the apple we’re looking for must be in the first half of the remaining boxes. So, we narrow down the search to the first two boxes and continue searching!")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Click on the boxes until you find the apple of size 40:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            ScrollView(.horizontal) {
                HStack(spacing: 15) {
                    ForEach(["G", "H"], id: \.self) { letter in
                        Group {
                            if activeLetters.contains(letter) {
                                NumberApple(number: letterNumbers[letter]!)
                                    .onTapGesture {
                                        Sounds.play(soundName: "btnClick")
                                        motor_optionSelect()
                                        withAnimation(.easeInOut){
                                            if let index = activeLetters.firstIndex(of: letter) {
                                                activeLetters.remove(at: index)
                                            }
                                        }
                                    }
                            } else {
                                LetterBox(letter: letter)
                                    .onTapGesture {
                                        Sounds.play(soundName: "btnClick")
                                        motor_optionSelect()
                                        withAnimation(.easeInOut){
                                            if !activeLetters.contains(letter) {
                                                activeLetters.append(letter)
                                            }
                                        }
                                    }
                            }
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if activeLetters.contains("H") {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 7/8
                                view = 8
                            }
                            updateLessonProgress(lessonName: "binary_search", progress: 7/8)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct K8: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    @Binding var time: Int
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Congratulations on finding the apple of size 40! Through this little game, we can see that binary search works by continuously halving the search range until we find the target. This greatly improves the search efficiency!")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 9
                    progress = 1
                }
                
                if time > 900 {
                    starCount -= 1
                }
                
                updateLessonProgress(lessonName: "binary_search", progress: 1)
                updateLessonStar(lessonName: "binary_search", star: starCount)
                setLessonStats(lessonName: "binary_search", stats: true)
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct K9: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @State private var code = """
import Foundation

func binarySearch() {
    let numbers = [1, 4, 7, 17, 29, 37, 39, 40, 56, 63, 66]
    let target = 40
    var left = 0
    var right = numbers.count - 1
    
    while left <= right {
        let middle = (left + right) / 2
        if numbers[middle] == target {
            print("Found \\(target) at index \\(middle)")
            return
        } else if numbers[middle] < target {
            left = middle + 1
        } else {
            right = middle - 1
        }
    }
    
    print("\\(target) not found")
}
"""
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Here’s an example of binary search in Swift, copy the code into Swift Playgrounds and give it a try!")
                Spacer()
            }
            
            SwiftCodeView(code: code)
            
            Spacer()
            
            Button(action: {
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 10
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

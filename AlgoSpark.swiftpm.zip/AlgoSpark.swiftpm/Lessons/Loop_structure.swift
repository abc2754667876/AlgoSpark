//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/19.
//

import SwiftUI

struct J_MAIN: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Environment(\.presentationMode) var presentationMode
    
    let onReload: () -> Void
    
    @State private var view = 1
    @State private var dismiss = false
    @State private var progress: CGFloat = 0/3
    @State private var starCount = 3
    @State private var time = 0
    @State private var timer: Timer? = nil
    @State private var showAlert = false
    
    var body: some View {
        NavigationView{
            ZStack{
                Color(.white)
                    .ignoresSafeArea()
                
                VStack{
                    HStack{
                        Button(action: {
                            Sounds.play(soundName: "btnClick")
                            showAlert = true
                            motor_return()
                        }){
                            ZStack{
                                Circle()
                                    .fill(Color(colorSet).opacity(0.1))
                                    .frame(width: 40, height: 40)
                                
                                Image("left_chev")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 18)
                                    .opacity(0.7)
                            }
                            .padding(.trailing, 8)
                        }
                        .alert(isPresented: $showAlert){
                            Alert(
                                title: Text("Exit"),
                                message: Text("Your progress might not be saved if you exit. "),
                                primaryButton: .destructive(Text("OK")) {
                                    onReload()
                                    presentationMode.wrappedValue.dismiss()
                                },
                                secondaryButton: .cancel {}
                            )
                        }
                        
                        MyProgressBar(progress: progress)
                            .padding(.trailing, 8)
                        
                        HStack{
                            Image("clock")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text(formatSecondsToMMSS(seconds: time))
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .frame(width: 60)
                                .lineLimit(1)
                                .foregroundStyle(.black)
                        }
                        
                        HStack{
                            Image("star")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text("\(starCount)")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .foregroundStyle(.black)
                        }
                    }
                    .padding()
                    
                    MyDivider()
                    
                    if view == 1 {
                        J1(view: $view, progress: $progress)
                    } else if view == 2 {
                        J2(view: $view, progress: $progress)
                    } else if view == 3 {
                        J3(view: $view, progress: $progress)
                    } else if view == 4 {
                        J4(view: $view, progress: $progress)
                    } else if view == 5 {
                        J5(view: $view, progress: $progress)
                    } else if view == 6 {
                        J6(view: $view, progress: $progress, starCount: $starCount, time: $time)
                    } else if view == 7 {
                        LessonResultView(dismiss: $dismiss, starCount: $starCount, time: $time, timer: $timer, onReload: onReload)
                    }
                }
            }
        }
        .onAppear{
            Sounds.play(soundName: "courseClick")
            motor_optionSelect()
            timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                DispatchQueue.main.async {
                    time += 1
                }
            }
        }
        .onChange(of: dismiss) { newValue in
            if newValue {
                presentationMode.wrappedValue.dismiss()
            }
        }
        .onChange(of: starCount) { newValue in
            if newValue < 1 {
                starCount = 1
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct J1: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Let’s learn the last type of program structure, called the loop structure.")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 2
                    progress = 1/6
                    updateLessonProgress(lessonName: "loop_structure", progress: 1/6)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct J2: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "In daily life, there are many examples of “loops.” For instance, jump rope training where you need to keep jumping many times to reach your goal, or memorizing a word where you read it, try to remember it, and repeat until you’ve learned it.")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 3
                    progress = 2/6
                    updateLessonProgress(lessonName: "loop_structure", progress: 2/6)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct J3: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    @State private var code = """
func brushTeeth() {
    for count in 1...30 {
        print("Brushing teeth: \\(count) times！")
    }
    
    print("My teeth are all clean!")
}
"""
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "We brush our teeth every day. To get them clean, we need to brush up and down about 30 times. Let’s use Swift code to simulate this looping process！")
                Spacer()
            }
            
            Spacer()
            
            SwiftCodeView(code: code)
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 4
                    progress = 3/6
                    updateLessonProgress(lessonName: "loop_structure", progress: 3/6)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct J4: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    @State private var code = """
func brushTeeth() {
    for count in 1...30 {
        print("Brushing teeth: \\(count) times！")
    }
    
    print("My teeth are all clean!")
}
"""
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "In this code, we use a for loop to create the repeating action. We define a range from 1 to 30, and for each loop, the code prints the current brushing count.")
                Spacer()
            }
            
            Spacer()
            
            SwiftCodeView(code: code)
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 5
                    progress = 4/6
                    updateLessonProgress(lessonName: "loop_structure", progress: 4/6)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct J5: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    @State private var code = """
func brushTeeth() {
    for count in 1...30 {
        print("Brushing teeth: \\(count) times！")
    }
    
    print("My teeth are all clean!")
}
"""
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "When the for loop finishes, the code will print: “My teeth are all clean!”")
                Spacer()
            }
            
            Spacer()
            
            SwiftCodeView(code: code)
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 6
                    progress = 5/6
                    updateLessonProgress(lessonName: "loop_structure", progress: 5/6)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct J6: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    @Binding var time: Int
    
    @State private var code = """
func vendingMachine() {
    // Sequential structure: initialization
    var selectedItem: String?
    var insertedMoney = 0
    var price = 0
    
    // Products and their prices
    let items = ["Coke": 5, "Water": 3, "Juice": 4]
    
    // Selection structure: prompt the user to choose a product
    print("Welcome to the vending machine! Please choose a product:")
    for (item, _) in items {
        print("- \\(item)")
    }
    
    // Get user input
    if let userInput = readLine() {
        if let itemPrice = items[userInput] {
            selectedItem = userInput
            price = itemPrice
            print("You selected \\(selectedItem!), the price is \\(price) units.")
        } else {
            print("Invalid selection, please choose a valid product.")
            return
        }
    }
    
    // Sequential structure: show price and allow the user to insert money
    print("Please enter the amount of money you want to insert:")
    
    // Loop structure: repeat inserting money until the amount is enough
    while insertedMoney < price {
        if let coin = readLine(), let coinAmount = Int(coin) {
            insertedMoney += coinAmount
            print("You have inserted \\(insertedMoney) units. You still need \\(price - insertedMoney) units.")
        } else {
            print("Invalid amount, please enter a valid amount.")
        }
    }
    
    // Selection structure: check if payment is enough
    if insertedMoney >= price {
        print("Payment successful! You have bought \\(selectedItem!), and your change is \\(insertedMoney - price) units.")
    } else {
        print("Payment failed! The amount is insufficient.")
    }
}
"""
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "In fact, all programs are made up of sequential structure, selection structure, and loop structure. Let’s look at an example of Swift code:")
                Spacer()
            }
            
            Spacer()
            
            SwiftCodeView(code: code)
            
            Spacer()
            
            Button(action: {
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 7
                    progress = 1
                }
                
                if time > 900 {
                    starCount -= 1
                }
                
                updateLessonProgress(lessonName: "loop_structure", progress: 1)
                updateLessonStar(lessonName: "loop_structure", star: starCount)
                setLessonStats(lessonName: "loop_structure", stats: true)
            }){
                NextButton()
            }
        }
        .padding()
    }
}

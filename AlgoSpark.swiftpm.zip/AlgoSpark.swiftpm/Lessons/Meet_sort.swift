//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/5.
//

import SwiftUI

struct C_MAIN: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Environment(\.presentationMode) var presentationMode
    
    let onReload: () -> Void
    
    @State private var view = 1
    @State private var dismiss = false
    @State private var progress: CGFloat = 0/3
    @State private var starCount = 3
    @State private var time = 0
    @State private var timer: Timer? = nil
    @State private var showAlert = false
    
    var body: some View {
        NavigationView{
            ZStack{
                Color(.white)
                    .ignoresSafeArea()
                
                VStack{
                    HStack{
                        Button(action: {
                            Sounds.play(soundName: "btnClick")
                            showAlert = true
                            motor_return()
                        }){
                            ZStack{
                                Circle()
                                    .fill(Color(colorSet).opacity(0.1))
                                    .frame(width: 40, height: 40)
                                
                                Image("left_chev")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 18)
                                    .opacity(0.7)
                            }
                            .padding(.trailing, 8)
                        }
                        .alert(isPresented: $showAlert){
                            Alert(
                                title: Text("Exit"),
                                message: Text("Your progress might not be saved if you exit. "),
                                primaryButton: .destructive(Text("OK")) {
                                    onReload()
                                    presentationMode.wrappedValue.dismiss()
                                },
                                secondaryButton: .cancel {}
                            )
                        }
                        
                        MyProgressBar(progress: progress)
                            .padding(.trailing, 8)
                        
                        HStack{
                            Image("clock")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text(formatSecondsToMMSS(seconds: time))
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .frame(width: 60)
                                .lineLimit(1)
                                .foregroundStyle(.black)
                        }
                        
                        HStack{
                            Image("star")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 25)
                            Text("\(starCount)")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .foregroundStyle(.black)
                        }
                    }
                    .padding()
                    
                    MyDivider()
                    
                    if view == 1 {
                        C1(view: $view, progress: $progress)
                    } else if view == 2 {
                        C2(view: $view, progress: $progress)
                    } else if view == 3 {
                        C3(view: $view, progress: $progress)
                    } else if view == 4 {
                        C4(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 5 {
                        C5(view: $view, progress: $progress)
                    } else if view == 6 {
                        C6(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 7 {
                        C7(view: $view, progress: $progress, starCount: $starCount)
                    } else if view == 8 {
                        C8(view: $view, progress: $progress, starCount: $starCount, time: $time)
                    } else if view == 9 {
                        C9(view: $view, progress: $progress, starCount: $starCount, time: $time)
                    } else if view == 10 {
                        C10(view: $view)
                    } else if view == 11 {
                        LessonResultView(dismiss: $dismiss, starCount: $starCount, time: $time, timer: $timer, onReload: onReload)
                    }
                }
            }
        }
        .onAppear{
            Sounds.play(soundName: "courseClick")
            motor_optionSelect()
            timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                DispatchQueue.main.async {
                    time += 1
                }
            }
        }
        .onChange(of: dismiss) { newValue in
            if newValue {
                presentationMode.wrappedValue.dismiss()
            }
        }
        .onChange(of: starCount) { newValue in
            if newValue < 1 {
                starCount = 1
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct C1: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Let’s officially start learning algorithms! From now on, we’ll explore sorting algorithms, searching algorithms, and more. Today, we’ll focus on understanding what a sorting algorithm is. ")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 2
                    progress = 1/9
                    updateLessonProgress(lessonName: "meet_sort", progress: 1/9)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct C2: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "In PE class, the teacher might ask us to line up from shortest to tallest. At home, our parents might ask us to organize books in alphabetical order. Once we’re done, we’ve completed a sorting task!")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 3
                    progress = 2/9
                    updateLessonProgress(lessonName: "meet_sort", progress: 2/9)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct C3: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "So, sorting is an algorithm that arranges a group of items in a specific order (like smallest to largest or largest to smallest) by comparing and swapping them. ")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 4
                    progress = 3/9
                    updateLessonProgress(lessonName: "meet_sort", progress: 3/0)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct C4: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var positions: [CGSize] = [.zero, .zero, .zero]
    @State private var bookOrder: [Int] = [0, 1, 2]
    @State private var answerStats = 0 
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Can you help me out? There are three books, but their order is all mixed up. Can you help me sort them by the first letter of their titles (A to Z)?")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Press and hold to drag the books into the correct order:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            HStack {
                ForEach(bookOrder.indices, id: \.self) { displayIndex in
                    let bookIndex = bookOrder[displayIndex]
                    Spacer()
                    Image(bookNames[bookIndex])
                        .resizable()
                        .scaledToFit()
                        .frame(width: 110)
                        .offset(positions[bookIndex])
                        .zIndex(positions[bookIndex] == .zero ? 0 : 1)
                        .gesture(
                            DragGesture()
                                .onChanged { value in
                                    positions[bookIndex] = value.translation
                                }
                                .onEnded { value in
                                    Sounds.play(soundName: "drag")
                                    motor_success()
                                    handleDragEnd(for: bookIndex, from: displayIndex, with: value.translation)
                                }
                        )
                }
                Spacer()
            }
            .padding()
            .animation(.spring(), value: bookOrder)
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if bookOrder.map({ bookNames[$0] }) == ["book_apple_adventure", "book_story_of_moonlights", "book_zebra_tales"] {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 4/9
                                view = 5
                            }
                            updateLessonProgress(lessonName: "meet_sort", progress: 4/9)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }

    private func handleDragEnd(for bookIndex: Int, from displayIndex: Int, with translation: CGSize) {
        let draggedBookCenter = CGFloat(displayIndex) + translation.width / 110.0
        let targetIndex = max(0, min(Int(round(draggedBookCenter)), bookOrder.count - 1))

        if targetIndex != displayIndex {
            withAnimation {
                bookOrder.remove(at: displayIndex)
                bookOrder.insert(bookIndex, at: targetIndex)
            }
        }

        positions[bookIndex] = .zero
    }

    private var bookNames: [String] {
        ["book_story_of_moonlights", "book_zebra_tales", "book_apple_adventure"]
    }
}

struct C5: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Congrats on completing the book-sorting game! Now, let’s play a number-sorting game!")
                Spacer()
            }
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 6
                    progress = 5/9
                    updateLessonProgress(lessonName: "meet_sort", progress: 5/9)
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

struct C6: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "The numbers at the top are already sorted, while the ones below are not. Follow the hints to arrange the numbers in ascending order.")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("If we’re arranging the numbers from smallest to largest, should 3 go to the left or right of 5? Click the correct box! ")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            VStack {
                HStack(spacing: 15) {
                    Button(action: {
                        Sounds.play(soundName: "optionSelect")
                        motor_optionSelect()
                        selectedBox = 1
                    }){
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .strokeBorder(style: StrokeStyle(lineWidth: 3, dash: [9]))
                                .foregroundColor(Color(colorSet).opacity(0.5))
                                .frame(width: 70, height: 70)
                            
                            if selectedBox == 1 {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.system(size: 25))
                                    .foregroundStyle(Color(colorSet))
                            }
                        }
                    }
                    
                    NumberCard(number: 5)
                    
                    Button(action: {
                        Sounds.play(soundName: "optionSelect")
                        motor_optionSelect()
                        selectedBox = 2
                    }){
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .strokeBorder(style: StrokeStyle(lineWidth: 3, dash: [9]))
                                .foregroundColor(Color(colorSet).opacity(0.5))
                                .frame(width: 70, height: 70)
                            
                            if selectedBox == 2 {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.system(size: 25))
                                    .foregroundStyle(Color(colorSet))
                            }
                        }
                    }
                    
                    Spacer()
                }
                
                Divider()
                    .padding(.vertical)
                
                HStack(spacing: 15) {
                    NumberCard(number: 3)
                    NumberCard(number: 8)
                    NumberCard(number: 6)
                    Spacer()
                }
            }
            .padding(.horizontal)
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if selectedBox == 1 {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else if selectedBox == 2 {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 6/9
                                view = 7
                            }
                            updateLessonProgress(lessonName: "meet_sort", progress: 6/9)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct C7: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "You’ve successfully sorted the number 3! Now it’s time to sort the number 8! ")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Should the number 8 go to the left or right of 5? Click the correct box! ")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            VStack {
                HStack(spacing: 15) {
                    NumberCard(number: 3)
                    
                    Button(action: {
                        Sounds.play(soundName: "optionSelect")
                        motor_optionSelect()
                        selectedBox = 1
                    }){
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .strokeBorder(style: StrokeStyle(lineWidth: 3, dash: [9]))
                                .foregroundColor(Color(colorSet).opacity(0.5))
                                .frame(width: 70, height: 70)
                            
                            if selectedBox == 1 {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.system(size: 25))
                                    .foregroundStyle(Color(colorSet))
                            }
                        }
                    }
                    
                    NumberCard(number: 5)
                    
                    Button(action: {
                        Sounds.play(soundName: "optionSelect")
                        motor_optionSelect()
                        selectedBox = 2
                    }){
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .strokeBorder(style: StrokeStyle(lineWidth: 3, dash: [9]))
                                .foregroundColor(Color(colorSet).opacity(0.5))
                                .frame(width: 70, height: 70)
                            
                            if selectedBox == 2 {
                                Image(systemName: "checkmark.circle.fill")
                                    .font(.system(size: 25))
                                    .foregroundStyle(Color(colorSet))
                            }
                        }
                    }
                    
                    Spacer()
                }
                
                Divider()
                    .padding(.vertical)
                
                HStack(spacing: 15) {
                    NumberCard(number: 8)
                    NumberCard(number: 6)
                    Spacer()
                }
            }
            .padding(.horizontal)
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if selectedBox == 2 {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else if selectedBox == 1 {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 7/9
                                view = 8
                            }
                            updateLessonProgress(lessonName: "meet_sort", progress: 7/9)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct C8: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    @Binding var time: Int
    
    @State private var selectedBox = 0
    
    @State private var answerStats = 0
    @State private var answerBgColor = ""
    @State private var answerBtColor = ""
    @State private var answerText = "BINGO!"
    @State private var checkButtonText = "CHECK"
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "You’ve successfully sorted the number 8! Now it’s time to sort the number 6! ")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("Should the number 6 go to the left or right of 5? Click the correct box! ")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            VStack {
                ScrollView(.horizontal){
                    HStack(spacing: 15) {
                        NumberCard(number: 3)
                        
                        Button(action: {
                            Sounds.play(soundName: "optionSelect")
                            motor_optionSelect()
                            selectedBox = 1
                        }){
                            ZStack {
                                RoundedRectangle(cornerRadius: 25)
                                    .strokeBorder(style: StrokeStyle(lineWidth: 3, dash: [9]))
                                    .foregroundColor(Color(colorSet).opacity(0.5))
                                    .frame(width: 70, height: 70)
                                
                                if selectedBox == 1 {
                                    Image(systemName: "checkmark.circle.fill")
                                        .font(.system(size: 25))
                                        .foregroundStyle(Color(colorSet))
                                }
                            }
                        }
                        
                        NumberCard(number: 5)
                        
                        Button(action: {
                            Sounds.play(soundName: "optionSelect")
                            motor_optionSelect()
                            selectedBox = 2
                        }){
                            ZStack {
                                RoundedRectangle(cornerRadius: 25)
                                    .strokeBorder(style: StrokeStyle(lineWidth: 3, dash: [9]))
                                    .foregroundColor(Color(colorSet).opacity(0.5))
                                    .frame(width: 70, height: 70)
                                
                                if selectedBox == 2 {
                                    Image(systemName: "checkmark.circle.fill")
                                        .font(.system(size: 25))
                                        .foregroundStyle(Color(colorSet))
                                }
                            }
                        }
                        
                        NumberCard(number: 8)
                    }
                    .padding(.bottom)
                }
                
                Divider()
                    .padding(.bottom)
                
                HStack(spacing: 15) {
                    NumberCard(number: 6)
                    Spacer()
                }
            }
            .padding(.horizontal)
            
            Spacer()
            
            ZStack{
                VStack{
                    HStack{
                        Text(answerText)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                        
                        Spacer()
                        
                        Image(systemName: answerStats == 1 ? "checkmark" : "xmark")
                            .bold()
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(answerBgColor))
                    }
                    .padding(.top, 25)
                    .padding(.bottom, 10)
                    Button(action: {
                        if checkButtonText == "CHECK" {
                            if selectedBox == 2 {
                                answerStats = 1
                                answerBgColor = "bingo"
                                answerBtColor = "bingo"
                                answerText = "BINGO!"
                                checkButtonText = "CONTINUE"
                                Sounds.play(soundName: "answerBingo")
                                motor_success()
                            } else if selectedBox == 1 {
                                answerStats = 2
                                answerBgColor = "wrong"
                                answerBtColor = "wrong"
                                answerText = "THINK TWICE!"
                                
                                if starCount >= 1 {
                                    starCount -= 1
                                }
                                
                                Sounds.play(soundName: "answerWrong")
                                motor_fail()
                            }
                        } else if checkButtonText == "CONTINUE" {
                            if starCount < 1 {
                                starCount = 1
                            }
                            
                            withAnimation(.easeInOut(duration: 0.5)){
                                progress = 8/9
                                view = 9
                            }
                            
                            updateLessonProgress(lessonName: "meet_sort", progress: 8/9)
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                        }
                    }){
                        MyButton_Custom(title: checkButtonText, fontSize: 20, isBold: true, color: answerBtColor)
                    }
                }
                .padding(.horizontal)
            }
            .background(Color(answerBgColor).opacity(0.15))
        }
        .onAppear{
            answerStats = 0
            answerBtColor = colorSet
            answerBgColor = "myClear"
        }
    }
}

struct C9: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @Binding var progress: CGFloat
    @Binding var starCount: Int
    @Binding var time: Int
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Congrats on completing the number sorting! During the process, we placed unsorted numbers into the correct spots among the sorted ones. This method of sorting is called “insertion sort”! ")
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)
            
            Spacer()
            
            HStack{
                Text("The correct order of the numbers is:")
                    .foregroundStyle(.black)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.leading)
                Spacer()
            }
            .padding(.horizontal)
            .padding(.bottom)
            
            HStack {
                Spacer()
                NumberCard(number: 3)
                Spacer()
                NumberCard(number: 5)
                Spacer()
                NumberCard(number: 6)
                Spacer()
                NumberCard(number: 8)
                Spacer()
            }
            .padding(.horizontal)
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                
                if time > 900 {
                    starCount -= 1
                }
                
                updateLessonStar(lessonName: "meet_sort", star: starCount)
                setLessonStats(lessonName: "meet_sort", stats: true)
                updateLessonProgress(lessonName: "meet_sort", progress: 1)
                
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 10
                    progress = 1
                }
            }){
                NextButton()
            }
        }
    }
}

struct C10: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    @Binding var view: Int
    @State private var code = """
import Foundation

func insertionSortAndPrint() {
    // Original Array
    var numbers = [5, 3, 8, 6]
    
    print("Before Sorting：\\(numbers)")
    
    // Logic of Insertion Sort
    for i in 1..<numbers.count {
        let key = numbers[i]
        var j = i - 1
        // Compare and Shift Elements
        while j >= 0 && numbers[j] > key {
            numbers[j + 1] = numbers[j]
            j -= 1
        }
        // Insert Current Element
        numbers[j + 1] = key
    }
    
    print("After Sorting：\\(numbers)")
}
"""
    
    var body: some View {
        VStack{
            HStack {
                ChatBubble(context: "Here’s the Swift code for insertion sort. If you want to dive deeper into learning this algorithm, copy the code into Swift Playgrounds and give it a try!")
                Spacer()
            }
            
            SwiftCodeView(code: code)
            
            Spacer()
            
            Button(action: {
                motor_buttonClick()
                withAnimation(.easeInOut(duration: 0.5)){
                    view = 11
                }
            }){
                NextButton()
            }
        }
        .padding()
    }
}

//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2024/12/28.
//

import SwiftUI

struct FirstUseView: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("firstUse") private var firstUse = true
    @AppStorage("with") private var with = "leo"
    @State private var selectedButton = 0
    
    var body: some View {
        ZStack{
            Color(.white)
                .ignoresSafeArea()
            
            VStack{
                Spacer()
                
                Image("algorithm")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 180)
                Text("Welcome to AlgoSpark!")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundStyle(.black)
                Text("Who do you want to study with?")
                    .font(.system(size: 16, weight: .regular, design: .rounded))
                    .foregroundStyle(.gray)
                    .padding(.top)
                
                HStack{
                    VStack{
                        Button(action: {
                            Sounds.play(soundName: "optionSelect")
                            selectedButton = 0
                            colorSet = "colorLeo"
                            with = "leo"
                            motor_optionSelect()
                        }){
                            ZStack{
                                Image("leo")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 90)
                                    .padding(20)
                            }
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(selectedButton == 0 ? Color(colorSet) : Color("myGray"), lineWidth: 4)
                            )
                        }
                        
                        Text("Leo")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(.black.opacity(0.8))
                    }

                    VStack {
                        Button(action: {
                            Sounds.play(soundName: "optionSelect")
                            selectedButton = 1
                            colorSet = "colorLuna"
                            with = "luna"
                            motor_optionSelect()
                        }){
                            ZStack{
                                Image("luna")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 90)
                                    .padding(20)
                            }
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(selectedButton == 1 ? Color(colorSet) : Color("myGray"), lineWidth: 4)
                            )
                        }
                        
                        Text("Luna")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(.black.opacity(0.8))
                    }
                    .padding(.leading)
                }
                .padding(.top)
                
                Spacer()
                
                Button(action: {
                    Sounds.play(soundName: "btnClick")
                    motor_buttonClick()
                    withAnimation(.easeInOut(duration: 0.7)){
                        firstUse = false
                    }
                }){
                    MyButton(title: "START", fontSize: 20, isBold: true)
                }
                .padding(.bottom)
                .padding(.horizontal)
            }
        }
    }
}

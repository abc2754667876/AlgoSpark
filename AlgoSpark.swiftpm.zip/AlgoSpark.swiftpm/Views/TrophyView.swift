//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/2/7.
//

import SwiftUI
import RealityKit
import ARKit
import Combine

struct TrophyView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var showSavedAlert = false
    @State private var takeEffect = false
    
    var body: some View {
        ZStack{
            ARViewContainer()
                .ignoresSafeArea()
            
            VStack{
                Spacer()
                
                Button(action: takePhoto) {
                    ZStack{
                        Circle()
                            .stroke(Color.white, lineWidth: 5)
                            .frame(width: 70, height: 70)
                        Circle()
                            .foregroundStyle(.white)
                            .frame(width: 58, height: 58)
                    }

                }
                .padding(.bottom)
            }

            Color(.white)
                .ignoresSafeArea()
                .opacity(takeEffect ? 1 : 0)
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button(action: {
                    motor_buttonClick()
                    Sounds.play(soundName: "btnClick")
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "arrowshape.left.fill")
                        .foregroundStyle(.white)
                        .font(.system(size: 22))
                }
            }
            
            ToolbarItem(placement: .principal) {
                Text("My Trophy")
                    .font(.system(size: 22, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
            }
        }
        .onAppear{
            motor_buttonClick()
            Sounds.play(soundName: "btnClick")
        }
    }
    
    private func takePhoto() {
        motor_success()
        Sounds.play(soundName: "camera")
        takeEffect = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            withAnimation(.easeInOut(duration: 1)){
                takeEffect = false
            }
        }
        
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first,
           let arView = window.findARView() {
            let _: () = arView.snapshot(saveToHDR: true) { image in
                if let image = image {
                    UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                    DispatchQueue.main.async {
                        showSavedAlert = true
                    }
                }
            }
        }
    }
}

struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal, .vertical]
        arView.session.run(config)
        
        if let modelEntity = try? Entity.load(named: "trophy.usdz") {
            let anchorEntity = AnchorEntity(world: [0, 0, -0.5])
            modelEntity.scale = [0.001, 0.001, 0.001]
            anchorEntity.addChild(modelEntity)
            arView.scene.addAnchor(anchorEntity)
        }
        
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
}

extension UIView {
    func findARView() -> ARView? {
        if let arView = self as? ARView {
            return arView
        }
        
        for subview in subviews {
            if let arView = subview.findARView() {
                return arView
            }
        }
        
        return nil
    }
}

#Preview {
    TrophyView()
}

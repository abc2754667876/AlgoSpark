//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/3.
//

import SwiftUI

struct LessonResultView: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    
    @Binding var dismiss: Bool
    @Binding var starCount: Int
    @Binding var time: Int
    @Binding var timer: Timer?
    let onReload: () -> Void
    
    @State private var isShow = true
    
    var body: some View {
        VStack{
            Spacer()
            
            Image("lessonComplete")
                .resizable()
                .scaledToFit()
                .frame(width: 180)
            
            Text("CONGRATULATIONS!")
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .foregroundStyle(.black)
                .padding(.top, -20)
                .padding(.bottom, 30)
            
            HStack{
                Spacer()
                
                VStack(spacing: 10){
                    Text("STARS")
                        .font(.system(size: 20, weight: .medium, design: .rounded))
                        .foregroundStyle(.gray)
                    Text("\(starCount)/3")
                        .font(.system(size: 30, weight: .black, design: .rounded))
                        .foregroundStyle(Color(colorSet))
                }
                .frame(maxWidth: .infinity)
                
                Spacer()
                
                Divider()
                    .frame(height: 70)
                    .frame(width: 1)
                    .background(Color("myGray"))
                    .rotationEffect(.degrees(0))
                    .padding(.horizontal, 10)
                
                Spacer()
                
                VStack(spacing: 10){
                    Text("TIME")
                        .font(.system(size: 20, weight: .medium, design: .rounded))
                        .foregroundStyle(.gray)
                    Text(formatSecondsToMMSS(seconds: time))
                        .font(.system(size: 30, weight: .black, design: .rounded))
                        .foregroundStyle(Color(colorSet))
                }
                .frame(maxWidth: .infinity)
                
                Spacer()
            }
            .padding(25)
            .frame(maxWidth: .infinity)
            .overlay(
                RoundedRectangle(cornerRadius: 30)
                    .stroke(Color("myGray"), lineWidth: 4)
            )
            
            Spacer()
            
            Button(action: {
                Sounds.play(soundName: "btnClick")
                motor_buttonClick()
                onReload()
                dismiss = true
            }){
                MyButton(title: "DONE", fontSize: 20, isBold: true)
            }
        }
        .onAppear{
            timer?.invalidate()
            timer = nil
            Sounds.play(soundName: "answerComplete")
        }
        .padding(.horizontal)
    }
}

//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2024/12/23.
//

import SwiftUI

struct HomeView: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    @AppStorage("showReviewInfo") private var showReviewInfo = false
    @AppStorage("showKeepInfo") private var showKeepInfo = false
    
    @State private var progress: Double = 0.5
    @State private var showActionSheet = false
    @State private var reloadID = UUID()
    @State private var showUnlockPopup = false
    @State private var unlockPopupTitle = "Collect at least 6 stars to unlock this course!"
    @State private var showInfoPopup = false
    @State private var infoPopupTitle = ""
    
    var body: some View {
        NavigationView{
            ZStack{
                Color(.white)
                    .ignoresSafeArea()
                
                VStack{
                    ScrollView(.vertical){
                        HStack{
                            Button(action: {
                                Sounds.play(soundName: "btnClick")
                                showActionSheet = true
                                motor_buttonClick()
                            }){
                                HStack{
                                    ZStack {
                                        Circle()
                                            .fill(Color(colorSet).opacity(0.1))
                                            .frame(width: 50, height: 50)
                                        
                                        Image(with)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 32)

                                    }
                                    
                                    Text(with == "leo" ? "Leo" : "Luna")
                                        .font(.system(size: 24, weight: .bold, design: .rounded))
                                        .padding(.leading, 5)
                                        .foregroundStyle(.black)
                                }
                            }
                            .actionSheet(isPresented: $showActionSheet) {
                                ActionSheet(
                                    title: Text("Choose Your Partner"),
                                    buttons: [
                                        .default(Text("Leo")) {
                                            Sounds.play(soundName: "optionSelect")
                                            motor_optionSelect()
                                            with = "leo"
                                            colorSet = "colorLeo"
                                        },
                                        .default(Text("Luna")) {
                                            Sounds.play(soundName: "optionSelect")
                                            motor_optionSelect()
                                            with = "luna"
                                            colorSet = "colorLuna"
                                        },
                                        .cancel()
                                    ]
                                )
                            }
                            
                            Spacer()
                            
                            HStack{
                                Image("fire")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 28)
                                
                                Text("lv\(getUserLv())")
                                    .font(.system(size: 24, weight: .bold, design: .rounded))
                                    .foregroundStyle(Color("myRed"))
                            }
                            
                            HStack{
                                Image("star")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 28)
                                
                                Text("\(getAllStar())")
                                    .font(.system(size: 24, weight: .bold, design: .rounded))
                                    .foregroundStyle(Color("myYellow"))
                            }
                            .padding(.leading)
                            
                            if getLessonStats(lessonName: "get_trophy") {
                                NavigationLink(destination: TrophyView()){
                                    Image("get_trophy")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 28)
                                }
                                .padding(.leading)
                            }
                        }
                        .padding(.top)
                        .padding(.horizontal)
                        
                        MyDivider()
                        
                        VStack{
                            HStack {
                                Text("What is algorithm")
                                    .foregroundStyle(.black)
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                Spacer()
                                
                                Image("star")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 20)
                                
                                HStack(spacing: 0){
                                    Text("\(getLessonsStar(lessons: ["whats_algorithm", "brush_teeth", "sequential_structure"]))")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                        .foregroundStyle(.black)
                                    Text("/9")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                        .foregroundStyle(.gray)
                                }

                                MyProgressBar_Small(progress: CGFloat(getLessonsStar(lessons: ["whats_algorithm", "brush_teeth", "sequential_structure"])) / 9)
                                    .frame(width: 100)
                            }
                            .padding(.top)
                            
                            ScrollView(.horizontal){
                                HStack(alignment: .top, spacing: 30){
                                    NavigationLink(destination: A_MAIN(onReload: reloadView)){
                                        HomeView_Card(progress: getLessonProgress(lessonName: "whats_algorithm"), imageName: "what_is_algo", title: "What's algorithm", isStar: getLessonStar(lessonName: "whats_algorithm") >= 3, isUnLock: true)
                                    }
                                    NavigationLink(destination: H_MAIN(onReload: reloadView)){
                                        HomeView_Card(progress: getLessonProgress(lessonName: "sequential_structure"), imageName: "sequential_structure", title: "Sequential Structure", isStar: getLessonStar(lessonName: "sequential_structure") >= 3, isUnLock: true)
                                    }
                                    
                                    if getAllStar() < 4 {
                                        HomeView_Card(progress: getLessonProgress(lessonName: "brush_teeth"), imageName: "brush_teeth", title: "Brush Teeth", isStar: getLessonStar(lessonName: "brush_teeth") >= 3, isUnLock: getAllStar() >= 4)
                                            .onTapGesture {
                                                Sounds.play(soundName: "answerWrong")
                                                motor_optionSelect()
                                                unlockPopupTitle = "Collect at least 4 stars to unlock this course!"
                                                withAnimation(.easeInOut(duration: 0.5)){
                                                    showUnlockPopup = true
                                                }
                                            }
                                    } else {
                                        NavigationLink(destination: B_MAIN(onReload: reloadView)){
                                            HomeView_Card(progress: getLessonProgress(lessonName: "brush_teeth"), imageName: "brush_teeth", title: "Brush Teeth", isStar: getLessonStar(lessonName: "brush_teeth") >= 3, isUnLock: getAllStar() >= 4)
                                        }
                                    }
                                }
                                .padding()
                            }
                        }
                        .padding(.horizontal)
                        
                        MyDivider()
                        
                        VStack{
                            HStack {
                                Text("Sorting")
                                    .foregroundStyle(.black)
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                Spacer()
                                
                                Image("star")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 20)
                                
                                HStack(spacing: 0){
                                    Text("\(getLessonsStar(lessons: ["meet_sort", "bubble_sort", "selection_sort", "bucket_sort", "selection_structure"]))")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                        .foregroundStyle(.black)
                                    Text("/15")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                        .foregroundStyle(.gray)
                                }

                                MyProgressBar_Small(progress: CGFloat(getLessonsStar(lessons: ["meet_sort", "bubble_sort", "selection_sort", "bucket_sort", "selection_structure"])) / 15)
                                    .frame(width: 100)
                            }
                            .padding(.top)
                            
                            ScrollView(.horizontal){
                                HStack(alignment: .top, spacing: 30){
                                    if getAllStar() < 6 {
                                        HomeView_Card(progress: getLessonProgress(lessonName: "meet_sort"), imageName: "sort", title: "Meet Sort", isStar: getLessonStar(lessonName: "meet_sort") >= 3, isUnLock: getAllStar() >= 6)
                                            .onTapGesture {
                                                Sounds.play(soundName: "answerWrong")
                                                motor_optionSelect()
                                                unlockPopupTitle = "Collect at least 6 stars to unlock this course!"
                                                withAnimation(.easeInOut(duration: 0.5)){
                                                    showUnlockPopup = true
                                                }
                                            }
                                    } else {
                                        NavigationLink(destination: C_MAIN(onReload: reloadView)){
                                            HomeView_Card(progress: getLessonProgress(lessonName: "meet_sort"), imageName: "sort", title: "Meet Sort", isStar: getLessonStar(lessonName: "meet_sort") >= 3, isUnLock: getAllStar() >= 6)
                                        }
                                    }
                                    
                                    if getAllStar() < 8 {
                                        HomeView_Card(progress: getLessonProgress(lessonName: "selection_structure"), imageName: "selection_structure", title: "Selection Structure", isStar: getLessonStar(lessonName: "selection_structure") >= 3, isUnLock: getAllStar() >= 8)
                                            .onTapGesture {
                                                Sounds.play(soundName: "answerWrong")
                                                motor_optionSelect()
                                                unlockPopupTitle = "Collect at least 8 stars to unlock this course!"
                                                withAnimation(.easeInOut(duration: 0.5)){
                                                    showUnlockPopup = true
                                                }
                                            }
                                    } else {
                                        NavigationLink(destination: I_MAIN(onReload: reloadView)){
                                            HomeView_Card(progress: getLessonProgress(lessonName: "selection_structure"), imageName: "selection_structure", title: "Selection Structure", isStar: getLessonStar(lessonName: "selection_structure") >= 3, isUnLock: getAllStar() >= 8)
                                        }
                                    }
                                    
                                    if getAllStar() < 10 {
                                        HomeView_Card(progress: getLessonProgress(lessonName: "bubble_sort"), imageName: "bubble_sort", title: "Bubble Sort", isStar: getLessonStar(lessonName: "bubble_sort") >= 3, isUnLock: getAllStar() >= 10)
                                            .onTapGesture {
                                                Sounds.play(soundName: "answerWrong")
                                                motor_optionSelect()
                                                unlockPopupTitle = "Collect at least 10 stars to unlock this course!"
                                                withAnimation(.easeInOut(duration: 0.5)){
                                                    showUnlockPopup = true
                                                }
                                            }
                                    } else {
                                        NavigationLink(destination: D_MAIN(onReload: reloadView)){
                                            HomeView_Card(progress: getLessonProgress(lessonName: "bubble_sort"), imageName: "bubble_sort", title: "Bubble Sort", isStar: getLessonStar(lessonName: "bubble_sort") >= 3, isUnLock: getAllStar() >= 10)
                                        }
                                    }
                                    
                                    if getAllStar() < 12 {
                                        HomeView_Card(progress: getLessonProgress(lessonName: "selection_sort"), imageName: "selection_sort", title: "Selection Sort", isStar: getLessonStar(lessonName: "selection_sort") >= 3, isUnLock: getAllStar() >= 12)
                                            .onTapGesture {
                                                Sounds.play(soundName: "answerWrong")
                                                motor_optionSelect()
                                                unlockPopupTitle = "Collect at least 12 stars to unlock this course!"
                                                withAnimation(.easeInOut(duration: 0.5)){
                                                    showUnlockPopup = true
                                                }
                                            }
                                    } else {
                                        NavigationLink(destination: E_MAIN(onReload: reloadView)){
                                            HomeView_Card(progress: getLessonProgress(lessonName: "selection_sort"), imageName: "selection_sort", title: "Selection Sort", isStar: getLessonStar(lessonName: "selection_sort") >= 3, isUnLock: getAllStar() >= 12)
                                        }
                                    }
                                    
                                    if getAllStar() < 14 {
                                        HomeView_Card(progress: getLessonProgress(lessonName: "bucket_sort"), imageName: "bucket_sort", title: "Bucket Sort", isStar: getLessonStar(lessonName: "bucket_sort") >= 3, isUnLock: getAllStar() >= 14)
                                            .onTapGesture {
                                                Sounds.play(soundName: "answerWrong")
                                                motor_optionSelect()
                                                unlockPopupTitle = "Collect at least 14 stars to unlock this course!"
                                                withAnimation(.easeInOut(duration: 0.5)){
                                                    showUnlockPopup = true
                                                }
                                            }
                                    } else {
                                        NavigationLink(destination: F_MAIN(onReload: reloadView)){
                                            HomeView_Card(progress: getLessonProgress(lessonName: "bucket_sort"), imageName: "bucket_sort", title: "Bucket Sort", isStar: getLessonStar(lessonName: "bucket_sort") >= 3, isUnLock: getAllStar() >= 14)
                                        }
                                    }
                                }
                                .padding()
                            }
                        }
                        .padding(.horizontal)
                        
                        MyDivider()
                        
                        VStack{
                            HStack {
                                Text("Searching")
                                    .foregroundStyle(.black)
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                Spacer()
                                
                                Image("star")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 20)
                                
                                HStack(spacing: 0){
                                    Text("\(getLessonsStar(lessons: ["meet_search", "binary_search", "loop_structure"]))")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                        .foregroundStyle(.black)
                                    Text("/9")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                        .foregroundStyle(.gray)
                                }

                                MyProgressBar_Small(progress: CGFloat(getLessonsStar(lessons: ["meet_search", "binary_search", "loop_structure"])) / 9)
                                    .frame(width: 100)
                            }
                            .padding(.top)
                            
                            ScrollView(.horizontal){
                                HStack(alignment: .top, spacing: 30){
                                    
                                    if getAllStar() < 16 {
                                        HomeView_Card(progress: getLessonProgress(lessonName: "meet_search"), imageName: "meet_search", title: "Meet Search", isStar: getLessonStar(lessonName: "meet_search") >= 3, isUnLock: getAllStar() >= 16)
                                            .onTapGesture {
                                                Sounds.play(soundName: "answerWrong")
                                                motor_optionSelect()
                                                unlockPopupTitle = "Collect at least 16 stars to unlock this course!"
                                                withAnimation(.easeInOut(duration: 0.5)){
                                                    showUnlockPopup = true
                                                }
                                            }
                                    } else {
                                        NavigationLink(destination: G_MAIN(onReload: reloadView)){
                                            HomeView_Card(progress: getLessonProgress(lessonName: "meet_search"), imageName: "meet_search", title: "Meet Search", isStar: getLessonStar(lessonName: "meet_search") >= 3, isUnLock: getAllStar() >= 16)
                                        }
                                    }
                                    
                                    if getAllStar() < 18 {
                                        HomeView_Card(progress: getLessonProgress(lessonName: "loop_structure"), imageName: "loop_structure", title: "Loop Structure", isStar: getLessonStar(lessonName: "loop_structure") >= 3, isUnLock: getAllStar() >= 18)
                                            .onTapGesture {
                                                Sounds.play(soundName: "answerWrong")
                                                motor_optionSelect()
                                                unlockPopupTitle = "Collect at least 18 stars to unlock this course!"
                                                withAnimation(.easeInOut(duration: 0.5)){
                                                    showUnlockPopup = true
                                                }
                                            }
                                    } else {
                                        NavigationLink(destination: J_MAIN(onReload: reloadView)){
                                            HomeView_Card(progress: getLessonProgress(lessonName: "loop_structure"), imageName: "loop_structure", title: "Loop Structure", isStar: getLessonStar(lessonName: "loop_structure") >= 3, isUnLock: getAllStar() >= 18)
                                        }
                                    }
                                    
                                    if getAllStar() < 20 {
                                        HomeView_Card(progress: getLessonProgress(lessonName: "binary_search"), imageName: "binary_search", title: "Binary Search", isStar: getLessonStar(lessonName: "binary_search") >= 3, isUnLock: getAllStar() >= 20)
                                            .onTapGesture {
                                                Sounds.play(soundName: "answerWrong")
                                                motor_optionSelect()
                                                unlockPopupTitle = "Collect at least 20 stars to unlock this course!"
                                                withAnimation(.easeInOut(duration: 0.5)){
                                                    showUnlockPopup = true
                                                }
                                            }
                                    }
                                    else {
                                        NavigationLink(destination: K_MAIN(onReload: reloadView)){
                                            HomeView_Card(progress: getLessonProgress(lessonName: "binary_search"), imageName: "binary_search", title: "Binary Search", isStar: getLessonStar(lessonName: "binary_search") >= 3, isUnLock: getAllStar() >= 20)
                                        }
                                    }

                                }
                                .padding()
                            }
                        }
                        .padding(.horizontal)
                        
                        MyDivider()
                        
                        VStack{
                            HStack {
                                Text("Solving Problems")
                                    .foregroundStyle(.black)
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                Spacer()
                                
                                Image("star")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 20)
                                
                                HStack(spacing: 0){
                                    Text("\(getLessonsStar(lessons: ["go_shopping", "eight_queens"]))")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                        .foregroundStyle(.black)
                                    Text("/6")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                        .foregroundStyle(.gray)
                                }

                                MyProgressBar_Small(progress: CGFloat(getLessonsStar(lessons: ["go_shopping", "eight_queens"])) / 6)
                                    .frame(width: 100)
                            }
                            .padding(.top)
                            
                            ScrollView(.horizontal){
                                HStack(alignment: .top, spacing: 30){
                                    if getAllStar() < 22 {
                                        HomeView_Card(progress: getLessonProgress(lessonName: "go_shopping"), imageName: "go_shopping", title: "Go Shopping", isStar: getLessonStar(lessonName: "go_shopping") >= 3, isUnLock: getAllStar() >= 22)
                                            .onTapGesture {
                                                Sounds.play(soundName: "answerWrong")
                                                motor_optionSelect()
                                                unlockPopupTitle = "Collect at least 22 stars to unlock this course!"
                                                withAnimation(.easeInOut(duration: 0.5)){
                                                    showUnlockPopup = true
                                                }
                                            }
                                    } else {
                                        NavigationLink(destination: L_MAIN(onReload: reloadView)){
                                            HomeView_Card(progress: getLessonProgress(lessonName: "go_shopping"), imageName: "go_shopping", title: "Go Shopping", isStar: getLessonStar(lessonName: "go_shopping") >= 3, isUnLock: getAllStar() >= 22)
                                        }
                                    }
                                    
                                    if getAllStar() < 24 {
                                        HomeView_Card(progress: getLessonProgress(lessonName: "eight_queens"), imageName: "eight_queens", title: "\"Eight\" Queens", isStar: getLessonStar(lessonName: "eight_queens") >= 3, isUnLock: getAllStar() >= 24)
                                            .onTapGesture {
                                                Sounds.play(soundName: "answerWrong")
                                                motor_optionSelect()
                                                unlockPopupTitle = "Collect at least 24 stars to unlock this course!"
                                                withAnimation(.easeInOut(duration: 0.5)){
                                                    showUnlockPopup = true
                                                }
                                            }
                                    } else {
                                        NavigationLink(destination: M_MAIN(onReload: reloadView)){
                                            HomeView_Card(progress: getLessonProgress(lessonName: "eight_queens"), imageName: "eight_queens", title: "\"Eight\" Queens", isStar: getLessonStar(lessonName: "eight_queens") >= 3, isUnLock: getAllStar() >= 24)
                                        }
                                    }
                                }
                                .padding()
                            }
                        }
                        .padding(.horizontal)
                        
                        MyDivider()
                        
                        VStack{
                            HStack {
                                Text(getAllStar() >= 30 ? "Get Trophy" : "???")
                                    .foregroundStyle(.black)
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                Spacer()
                                
                                Image("star")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 20)
                                
                                HStack(spacing: 0){
                                    Text("\(getLessonsStar(lessons: ["get_trophy"]))")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                        .foregroundStyle(.black)
                                    Text("/3")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                        .foregroundStyle(.gray)
                                }

                                MyProgressBar_Small(progress: CGFloat(getLessonsStar(lessons: ["get_trophy"])) / 3)
                                    .frame(width: 100)
                            }
                            .padding(.top)
                            
                            ScrollView(.horizontal){
                                HStack(alignment: .top, spacing: 30){
                                    if getAllStar() < 30 {
                                        HomeView_Card(progress: getLessonProgress(lessonName: "get_trophy"), imageName: getAllStar() >= 30 ? "get_trophy" : "question_mark", title: getAllStar() >= 30 ? "Get Trophy" : "???", isStar: getLessonStar(lessonName: "get_trophy") >= 3, isUnLock: getAllStar() >= 30)
                                            .onTapGesture {
                                                Sounds.play(soundName: "answerWrong")
                                                motor_optionSelect()
                                                unlockPopupTitle = "Collect at least 30 stars to see what this cource is and unlock this course!"
                                                withAnimation(.easeInOut(duration: 0.5)){
                                                    showUnlockPopup = true
                                                }
                                            }
                                    } else {
                                        NavigationLink(destination: N_MAIN(onReload: reloadView)){
                                            HomeView_Card(progress: getLessonProgress(lessonName: "get_trophy"), imageName: getAllStar() >= 30 ? "get_trophy" : "question_mark", title: getAllStar() >= 30 ? "Get Trophy" : "???", isStar: getLessonStar(lessonName: "get_trophy") >= 3, isUnLock: getAllStar() >= 30)
                                        }
                                    }
                                }
                                .padding()
                            }
                        }
                        .padding(.horizontal)
                        
                        if getLessonStats(lessonName: "get_trophy") {
                            NavigationLink(destination: TrophyView()){
                                HStack{
                                    Image("trophy2")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 30)
                                    Text("VIEW MY TROPHY IN AR")
                                        .font(.system(size: 20, weight: .black, design: .rounded))
                                        .foregroundColor(.white)
                                }
                                .frame(height: 60)
                                .frame(maxWidth: .infinity)
                                .background(
                                    ZStack {
                                        LinearGradient(
                                            gradient: Gradient(colors: [Color(colorSet).opacity(0.9), Color(colorSet)]),
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        )
                                        .clipShape(Capsule())
                                        
                                        Capsule()
                                            .stroke(Color.black.opacity(0.3), lineWidth: 2)
                                            .blur(radius: 2)
                                            .offset(x: -2, y: -2)
                                    }
                                )
                                .clipShape(Capsule())
                            }
                            .padding(.bottom)
                            .padding(.horizontal)

                        }
                    }
                }
                
                if showUnlockPopup {
                    ZStack{
                        Color(.black)
                            .ignoresSafeArea()
                            .opacity(0.5)
                    }
                    
                    VStack(spacing: 15){
                        Image("star")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 70)
                            .shadow(color: Color("myYellow").opacity(0.5), radius: 15)
                        Text(unlockPopupTitle)
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 30)
                        Button(action: {
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                            withAnimation(.easeInOut(duration: 0.5)){
                                showUnlockPopup = false
                            }
                        }){
                            MyButton(title: "KEEP GOING", fontSize: 20, isBold: true)
                                .padding(.top)
                        }
                    }
                    .padding(.vertical, 30)
                    .padding(.horizontal, 30)
                    .background(.white)
                    .cornerRadius(20)
                    .padding()
                }
                
                if showInfoPopup {
                    ZStack{
                        Color(.black)
                            .ignoresSafeArea()
                            .opacity(0.5)
                    }
                    
                    VStack(spacing: 15){
                        Image(with)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 70)
                        Text(infoPopupTitle)
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 30)
                        Button(action: {
                            Sounds.play(soundName: "btnClick")
                            motor_buttonClick()
                            withAnimation(.easeInOut(duration: 0.5)){
                                showInfoPopup = false
                            }
                        }){
                            MyButton(title: "KEEP GOING", fontSize: 20, isBold: true)
                                .padding(.top)
                        }
                    }
                    .padding(.vertical, 30)
                    .padding(.horizontal, 30)
                    .background(.white)
                    .cornerRadius(20)
                    .padding()
                }
            }
        }
        .id(reloadID)
        .navigationViewStyle(StackNavigationViewStyle())
        .onAppear{
            if !showKeepInfo && getLessonStats(lessonName: "whats_algorithm") && getLessonStar(lessonName: "whats_algorithm") < 3 {
                showKeepInfo = true
                infoPopupTitle = "Even though you didn’t get three stars, you can always come back and try again!"
                showInfoPopup = true
            }
            if !showReviewInfo && getLessonStats(lessonName: "whats_algorithm") && getLessonStar(lessonName: "whats_algorithm") >= 3 {
                showReviewInfo = true
                infoPopupTitle = "Congratulations on earning three stars! Remember, you can always come back to review!"
                showInfoPopup = true
            }
        }
    }
    
    func reloadView() {
        reloadID = UUID()
    }
}

#Preview {
    HomeView()
}

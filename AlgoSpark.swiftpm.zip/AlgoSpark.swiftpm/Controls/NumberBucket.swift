//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/9.
//

import SwiftUI

struct NumberBucket: View {
    var numbers: String
    
    var body: some View {
        ZStack{
            Image("bucket")
                .resizable()
                .scaledToFit()
                .frame(width: 110)
            Text(numbers)
                .font(.system(size: 18, weight: .black, design: .rounded))
                .foregroundStyle(.white)
                .padding(.top, 25)
        }
    }
}

//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2024/12/28.
//

import SwiftUI

struct MyButton: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    
    var title: String
    var fontSize: CGFloat
    var isBold: Bool
    
    var body: some View {
        Text(title)
            .font(.system(size: fontSize, weight: isBold ? .bold : .regular, design: .rounded))
            .foregroundColor(.white)
            .padding()
            .frame(height: 50)
            .frame(maxWidth: .infinity)
            .background(
                ZStack {
                    LinearGradient(
                        gradient: Gradient(colors: [Color(colorSet).opacity(0.9), Color(colorSet)]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    .clipShape(Capsule())
                    
                    Capsule()
                        .stroke(Color.black.opacity(0.3), lineWidth: 2)
                        .blur(radius: 2)
                        .offset(x: -2, y: -2)
                }
            )
            .clipShape(Capsule())
    }
}

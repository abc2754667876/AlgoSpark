//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2024/12/29.
//

import SwiftUI

struct HomeView_Card: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    
    var progress: CGFloat
    var imageName: String
    var title: String
    var isStar: Bool
    var isUnLock: Bool
    
    var body: some View {
        VStack{
            ZStack{
                ZStack {
                    RectangleRingShape()
                        .stroke(Color(colorSet).opacity(0.1), lineWidth: 11)
                    
                    RectangleRingShape()
                        .trim(from: 0, to: CGFloat(progress))
                        .stroke(Color(colorSet), style: StrokeStyle(
                            lineWidth: 11,
                            lineCap: .round
                        ))

                    ZStack{
                        Color(colorSet).opacity(0.1)
                        
                        Image(imageName)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 40, height: 40)
                    }
                    .cornerRadius(15)
                    .padding(12)
                    
                    if !isUnLock {
                        VStack {
                            Spacer()
                            HStack {
                                Spacer()
                                Image("lock")
                                    .resizable()
                                    .frame(width: 45, height: 40)
                                    .offset(x: 10, y: 5)
                            }
                        }
                        .frame(width: 95, height: 95)
                    } else {
                        if isStar {
                            VStack {
                                Spacer()
                                HStack {
                                    Spacer()
                                    Image("star_white")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 50, height: 50)
                                        .offset(x: 10, y: 10)
                                }
                            }
                            .frame(width: 95, height: 95)
                        }
                    }
                }
                .frame(width: 95, height: 95)
                
                /*
                if !isUnLock {
                    ZStack{
                        Color(.black).opacity(0.35)
                    }
                    .frame(width: 107, height: 107)
                    .cornerRadius(32)
                    
                    Image("lock")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50)
                }
                 */
            }

            Text(title)
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .multilineTextAlignment(.center)
                .padding(.top, 5)
                .frame(width: 95)
                .foregroundStyle(.black)
        }
    }
}

struct RectangleRingShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        let cornerRadius: CGFloat = 25
        
        path.move(to: CGPoint(x: rect.minX + cornerRadius, y: rect.minY))
        
        path.addLine(to: CGPoint(x: rect.maxX - cornerRadius, y: rect.minY))
        path.addArc(center: CGPoint(x: rect.maxX - cornerRadius, y: rect.minY + cornerRadius),
                   radius: cornerRadius,
                   startAngle: .degrees(-90),
                   endAngle: .degrees(0),
                   clockwise: false)
        
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - cornerRadius))
        path.addArc(center: CGPoint(x: rect.maxX - cornerRadius, y: rect.maxY - cornerRadius),
                   radius: cornerRadius,
                   startAngle: .degrees(0),
                   endAngle: .degrees(90),
                   clockwise: false)
        
        path.addLine(to: CGPoint(x: rect.minX + cornerRadius, y: rect.maxY))
        path.addArc(center: CGPoint(x: rect.minX + cornerRadius, y: rect.maxY - cornerRadius),
                   radius: cornerRadius,
                   startAngle: .degrees(90),
                   endAngle: .degrees(180),
                   clockwise: false)
        
        path.addLine(to: CGPoint(x: rect.minX, y: rect.minY + cornerRadius))
        path.addArc(center: CGPoint(x: rect.minX + cornerRadius, y: rect.minY + cornerRadius),
                   radius: cornerRadius,
                   startAngle: .degrees(180),
                   endAngle: .degrees(270),
                   clockwise: false)
        
        return path
    }
}


#Preview {
    HomeView_Card(progress: 1, imageName: "what_is_algo", title: "What is algorithm?", isStar: false, isUnLock: false)
}

//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/1.
//

import SwiftUI

struct ChatBubble: View {
    @AppStorage("with") private var with = "leo"
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    
    var context: String
    
    var body: some View {
        HStack(alignment: .top){
            Image(with)
                .resizable()
                .scaledToFit()
                .frame(width: 100)
            
            ZStack{
                Text(context)
                    .foregroundStyle(Color(colorSet))
                    .font(.system(size: 20, weight: .black, design: .rounded))
                    .multilineTextAlignment(.leading)
                    .padding(.horizontal, 25)
                    .padding(.vertical, 15)
            }
            .background(Color(colorSet).opacity(0.05))
            .clipShape(CustomRoundedCorners(radius: 25, corners: [.bottomLeft, .bottomRight, .topRight]))
        }
    }
}


struct CustomRoundedCorners: Shape {
    var radius: CGFloat
    var corners: UIRectCorner

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}

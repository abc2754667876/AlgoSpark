//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/1.
//

import SwiftUI

struct NextButton: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    
    var body: some View {
        ZStack{
            Image("right_chev")
                .resizable()
                .scaledToFit()
                .frame(width: 35, height: 35)
        }
        .frame(width: 80, height: 80)
        .background(
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color(colorSet).opacity(0.9), Color(colorSet)]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .clipShape(Capsule())
                
                Capsule()
                    .stroke(Color.black.opacity(0.3), lineWidth: 2)
                    .blur(radius: 2)
                    .offset(x: -2, y: -2)
            }
        )
        .clipShape(Capsule())
    }
}

//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/2.
//

import SwiftUI

struct Options: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    
    var content: String
    var selected: Bool
    
    var body: some View {
        HStack{
            Text(content)
                .multilineTextAlignment(.leading)
                .font(.system(size: 19, weight: .medium, design: .rounded))
            Spacer()
        }
        .padding(25)
        .frame(maxWidth: .infinity)
        .overlay(
            RoundedRectangle(cornerRadius: 30)
                .stroke(selected ? Color(colorSet) : Color("myGray"), lineWidth: 4)
        )
    }
}

//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/4.
//

import SwiftUI

struct MyProgressBar_Small: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    
    var progress: CGFloat
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Rectangle()
                    .frame(height: 10)
                    .foregroundColor(Color(colorSet).opacity(0.1))
                    .cornerRadius(10)
                
                Rectangle()
                    .frame(width: min(max(progress, 0), 1) * geometry.size.width, height: 10)
                    .foregroundStyle(Color(colorSet))
                    .cornerRadius(10)
            }
        }
        .frame(height: 10) 
    }
}

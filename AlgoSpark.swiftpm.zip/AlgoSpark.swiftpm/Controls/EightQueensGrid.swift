//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/2/5.
//

import SwiftUI

struct EightQueensGrid: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @Binding var selectedCells: [(Int, Int)]
    
    var body: some View {
        ZStack {
            HStack(spacing: 0) {
                ForEach(0..<4) { column in
                    VStack(spacing: 0) {
                        ForEach(0..<4) { row in
                            ZStack {
                                if selectedCells.contains(where: { $0 == (row, column) }) {
                                    Image("eight_queens")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 30)
                                        .shadow(color: .black.opacity(0.3), radius: 5)
                                }
                            }
                            .frame(width: 62, height: 62)
                            .background(
                                Color(colorSet)
                                    .opacity((row + column).isMultiple(of: 2) ? 1 : 0.2)
                            )
                            .onTapGesture {
                                Sounds.play(soundName: "optionSelect")
                                toggleCell(row: row, column: column)
                            }
                        }
                    }
                }
            }
        }
        .padding()
        .border(Color(colorSet), width: 8)
    }
    
    private func toggleCell(row: Int, column: Int) {
        motor_optionSelect()
        if let index = selectedCells.firstIndex(where: { $0 == (row, column) }) {
            selectedCells.remove(at: index)
        } else {
            selectedCells.append((row, column))
        }
    }
}

struct EightQueensGrid_Five: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @Binding var selectedCells: [(Int, Int)]
    
    var body: some View {
        ZStack {
            HStack(spacing: 0) {
                ForEach(0..<5) { column in
                    VStack(spacing: 0) {
                        ForEach(0..<5) { row in
                            ZStack {
                                if selectedCells.contains(where: { $0 == (row, column) }) {
                                    Image("eight_queens")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 28)
                                        .shadow(color: .black.opacity(0.3), radius: 5)
                                }
                            }
                            .frame(width: 58, height: 58)
                            .background(
                                Color(colorSet)
                                    .opacity((row + column).isMultiple(of: 2) ? 1 : 0.2)
                            )
                            .onTapGesture {
                                Sounds.play(soundName: "optionSelect")
                                toggleCell(row: row, column: column)
                            }
                        }
                    }
                }
            }
        }
        .padding()
        .border(Color(colorSet), width: 8)
    }
    
    private func toggleCell(row: Int, column: Int) {
        motor_optionSelect()
        if let index = selectedCells.firstIndex(where: { $0 == (row, column) }) {
            selectedCells.remove(at: index)
        } else {
            selectedCells.append((row, column))
        }
    }
}

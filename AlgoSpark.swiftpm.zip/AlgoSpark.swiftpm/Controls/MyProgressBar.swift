//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/1.
//

import SwiftUI

struct MyProgressBar: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    
    var progress: CGFloat
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Rectangle()
                    .frame(height: 15)
                    .foregroundColor(Color(colorSet).opacity(0.1))
                    .cornerRadius(10)
                
                ZStack{
                    Rectangle()
                        .frame(width: min(max(progress, 0), 1) * geometry.size.width, height: 15)
                        .foregroundStyle(Color(colorSet))
                        .cornerRadius(10)
                    
                    Rectangle()
                        .frame(width: min(max(progress, 0), 1) * geometry.size.width - 40, height: 4)
                        .foregroundStyle(Color(.white).opacity(0.35))
                        .cornerRadius(10)
                        .offset(x: 0, y: -2)
                }
            }
        }
        .frame(height: 15)
    }
}

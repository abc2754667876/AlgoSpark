//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2024/12/28.
//

import SwiftUI

struct MyDivider: View {
    var body: some View {
        ZStack{}
            .frame(maxWidth: .infinity)
            .frame(height: 4)
            .background(Color("myGray"))
    }
}

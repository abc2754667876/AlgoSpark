//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/9.
//

import SwiftUI

struct NumberApple: View {
    var number: Int
    
    var body: some View {
        ZStack{
            Image("apple")
                .resizable()
                .scaledToFit()
                .frame(width: 70)
            Text("\(number)")
                .font(.system(size: 25, weight: .black, design: .rounded))
                .foregroundStyle(.white)
                .padding(.top, 20)
        }
    }
}

struct SelectableNumberApple: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    
    let number: Int
    @Binding var selectedApples: [Int]

    var isSelected: Bool {
        selectedApples.contains(number)
    }

    var body: some View {
        ZStack {
            NumberApple(number: number)
                .onTapGesture {
                    Sounds.play(soundName: "optionSelect")
                    motor_optionSelect()
                    toggleSelection()
                }
            if isSelected {
                HStack {
                    VStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(Color(colorSet))
                            .padding(10)
                        Spacer()
                    }
                    Spacer()
                }
            }
        }
        .frame(width: 100, height: 100)
        .overlay(
            RoundedRectangle(cornerRadius: 15)
                .stroke(isSelected ? Color(colorSet) : Color.clear, lineWidth: 4)
        )
    }

    private func toggleSelection() {
        if isSelected {
            selectedApples.removeAll { $0 == number }
        } else {
            selectedApples.append(number)
        }
    }
}

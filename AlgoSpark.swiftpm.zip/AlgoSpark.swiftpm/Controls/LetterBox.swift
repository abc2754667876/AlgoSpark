//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/30.
//

import SwiftUI

struct LetterBox: View {
    var letter: String
    
    var body: some View {
        ZStack{
            Image("box")
                .resizable()
                .scaledToFit()
                .frame(width: 80)
            Text(letter)
                .font(.system(size: 30, weight: .black, design: .rounded))
                .foregroundStyle(.white)
                .padding(.top, 10)
        }
    }
}

#Preview {
    LetterBox(letter: "A")
}

//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/4.
//

import SwiftUI
import UIKit

struct SwiftCodeView: View {
    let code: String
    
    @State private var copied = false

    var body: some View {
        ZStack {
            VStack{
                ZStack{
                    Color("myGray")
                    
                    HStack{
                        Image("swift")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 17)
                        
                        Spacer()
                        
                        Button(action: {
                            UIPasteboard.general.string = code
                            Sounds.play(soundName: "btnClick")
                            motor_success()
                            withAnimation(.easeInOut(duration: 0.5)){
                                copied = true
                            }
                        }){
                            if !copied {
                                HStack{
                                    Image(systemName: "document.on.document")
                                    Text("Copy")
                                        .padding(.leading, -5)
                                }
                                .font(.system(size: 14))
                                .foregroundStyle(.black)
                            } else {
                                Image(systemName: "checkmark")
                                    .font(.system(size: 14))
                                    .foregroundStyle(.black)
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                .frame(height: 45)
                .clipShape(CustomRoundedCorners(radius: 10, corners: [.topLeft, .topRight]))
                
                ScrollView(.vertical) {
                    HStack {
                        Text(highlightedCode())
                            .font(.system(size: 15, design: .monospaced))
                            .foregroundColor(.primary)
                            .cornerRadius(10)
                            .textSelection(.enabled)
                        Spacer()
                    }
                    .padding()
                }
            }
            .frame(maxHeight: .infinity)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(
                        Color("myGray"),
                        lineWidth: 1
                    )
            )
        }
        .padding(.vertical, 30)
    }

    private func highlightedCode() -> AttributedString {
        var attributedString = AttributedString(code)

        let patterns: [String: Color] = [
            "\\b(import|struct|func|var|while|for|in|let|return|if|else|else if)\\b": Color(hex: "a3359a"),
            "\".*?\"": Color(hex: "cb291a"),
            "\\b[0-9]+\\b": .orange,
            "//.*?$": .gray
        ]

        // 应用每个正则表达式
        for (pattern, color) in patterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.anchorsMatchLines]) {
                let matches = regex.matches(in: code, range: NSRange(location: 0, length: code.utf16.count))
                for match in matches {
                    if let range = Range(match.range, in: code) {
                        let swiftRange = attributedString.range(of: String(code[range]))
                        attributedString[swiftRange!].foregroundColor = color
                    }
                }
            }
        }

        return attributedString
    }
}

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        let scanner = Scanner(string: hex)
        
        if hex.hasPrefix("#") {
            scanner.currentIndex = hex.index(after: hex.startIndex)
        }
        
        var rgb: UInt64 = 0
        scanner.scanHexInt64(&rgb)
        
        let red = Double((rgb >> 16) & 0xFF) / 255.0
        let green = Double((rgb >> 8) & 0xFF) / 255.0
        let blue = Double(rgb & 0xFF) / 255.0
        
        self.init(red: red, green: green, blue: blue)
    }
}

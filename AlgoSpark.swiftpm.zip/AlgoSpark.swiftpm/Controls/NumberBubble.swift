//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/7.
//

import SwiftUI

struct NumberBubble: View {
    var number: Int
    
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    @AppStorage("with") private var with = "leo"
    
    var body: some View {
        ZStack{
            Text("\(number)")
                .foregroundStyle(Color(colorSet))
                .font(.system(size: 45, weight: .black, design: .rounded))
            
            Image(with == "leo" ? "bubbleLeo" : "bubbleLuna")
                .resizable()
                .scaledToFit()
                .frame(width: 75)
        }
    }
}

//
//  SwiftUIView.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/5.
//

import SwiftUI

struct NumberCard: View {
    @AppStorage("colorSet") private var colorSet = "colorLeo"
    
    var number: Int
    
    var body: some View {
        ZStack{
            Color(colorSet).opacity(0.2)
            
            Text("\(number)")
                .foregroundStyle(Color(colorSet))
                .font(.system(size: 40, weight: .black, design: .rounded))
                .shadow(color: Color(colorSet).opacity(0.3), radius: 5)
        }
        .frame(width: 70, height: 70)
        .cornerRadius(25)
    }
}

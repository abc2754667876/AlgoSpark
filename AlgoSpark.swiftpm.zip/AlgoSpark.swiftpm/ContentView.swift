import SwiftUI

struct ContentView: View {
    @AppStorage("firstUse") private var firstUse = true
    
    var body: some View {
        if firstUse {
            FirstUseView()
        } else {
            HomeView()
        }
    }
}

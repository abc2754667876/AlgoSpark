//
//  File.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/3.
//

import Foundation

let lessons = ["whats_algorithm", "brush_teeth", "meet_sort", "bubble_sort", "selection_sort", "bucket_sort", "meet_search", "binary_search", "sequential_structure", "selection_structure", "loop_structure", "go_shopping", "eight_queens", "get_trophy"]

func formatSecondsToMMSS(seconds: Int) -> String {
    let minutes = seconds / 60
    let remainingSeconds = seconds % 60
    return String(format: "%02d:%02d", minutes, remainingSeconds)
}

func setLessonProgress(lessonName: String, progress: CGFloat){
    UserDefaults.standard.set(Double(progress), forKey: "lessonProgress_\(lessonName)")
}

func getLessonProgress(lessonName: String) -> CGFloat{
    let value = UserDefaults.standard.double(forKey: "lessonProgress_\(lessonName)")
    return CGFloat(value)
}

func updateLessonProgress(lessonName: String, progress: CGFloat){
    if progress >= getLessonProgress(lessonName: lessonName) {
        setLessonProgress(lessonName: lessonName, progress: progress)
    }
}

func getUserLv() -> Int{
    var lv: Int = 0
    
    if getLessonProgress(lessonName: "whats_algorithm") + getLessonProgress(lessonName: "brush_teeth") + getLessonProgress(lessonName: "sequential_structure") >= 3 {
        lv = 1
    }
    
    if getLessonProgress(lessonName: "meet_sort") + getLessonProgress(lessonName: "bubble_sort") + getLessonProgress(lessonName: "selection_sort") + getLessonProgress(lessonName: "bucket_sort") + getLessonProgress(lessonName: "selection_structure") >= 5 {
        lv = 2
    }
    
    if getLessonProgress(lessonName: "meet_search") + getLessonProgress(lessonName: "loop_structure") + getLessonProgress(lessonName: "binary_search") >= 3 {
        lv = 3
    }
    
    if getLessonProgress(lessonName: "eight_queens") + getLessonProgress(lessonName: "go_shopping") >= 2 {
        lv = 4
    }
    
    if getLessonProgress(lessonName: "get_trophy") >= 1 {
        lv = 5
    }
    
    return lv
}

func setLessonStar(lessonName: String, star: Int){
    UserDefaults.standard.set(star, forKey: "lessonStar_\(lessonName)")
}

func getLessonStar(lessonName: String) -> Int{
    let value = UserDefaults.standard.integer(forKey: "lessonStar_\(lessonName)")
    return value
}

func updateLessonStar(lessonName: String, star: Int){
    if star >= getLessonStar(lessonName: lessonName) {
        setLessonStar(lessonName: lessonName, star: star)
    }
}

func getLessonsStar(lessons: [String]) -> Int{
    var stars: Int = 0
    for lesson in lessons {
        stars += getLessonStar(lessonName: lesson)
    }
    return stars
}

func getAllStar() -> Int {
    var stars: Int = 0
    for lesson in lessons {
        stars += getLessonStar(lessonName: lesson)
    }
    return stars
}

func setLessonStats(lessonName: String, stats: Bool){
    UserDefaults.standard.set(stats, forKey: "lessonStats_\(lessonName)")
}

func getLessonStats(lessonName: String) -> Bool{
    let value = UserDefaults.standard.bool(forKey: "lessonStats_\(lessonName)")
    return value
}

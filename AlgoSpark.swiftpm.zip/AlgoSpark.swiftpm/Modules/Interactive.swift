//
//  File.swift
//  AlgoSpark
//
//  Created by Chengzhi 张 on 2025/1/2.
//

import Foundation
import SwiftUI
import AVFoundation

@MainActor func motor_buttonClick(){
    let generator = UIImpactFeedbackGenerator(style: .medium)
    generator.impactOccurred()
}

@MainActor func motor_optionSelect(){
    let generator = UIImpactFeedbackGenerator(style: .rigid)
    generator.impactOccurred()
}

@MainActor func motor_return(){
    let generator = UIImpactFeedbackGenerator(style: .soft)
    generator.impactOccurred()
}

@MainActor func motor_success(){
    UINotificationFeedbackGenerator().notificationOccurred(.success)
}

@MainActor func motor_fail(){
    UINotificationFeedbackGenerator().notificationOccurred(.error)
}

class Sounds {
    static var player: AVAudioPlayer?
    
    static func play(soundName: String) {
        guard let soundURL = Bundle.main.url(forResource: soundName, withExtension: "mp3") else {
            return
        }
        
        do {
            player = try AVAudioPlayer(contentsOf: soundURL)
        } catch {
            print("Failed to load the sound: \(error)")
        }
        player?.play()
    }
}
